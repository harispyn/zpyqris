<?php
// ============================================================
// QRIS ZIPAY - KONFIGURASI APLIKASI
// ============================================================

define('APP_NAME',    'QRIS Scan Pay API');
define('APP_VERSION', '1.0.0');
define('APP_ENV',     'development'); // development | production
define('APP_URL',     'http://localhost/qris-zipay');
define('APP_DEBUG',   true);

// Timezone
date_default_timezone_set('Asia/Jakarta');

// JWT Configuration
define('JWT_SECRET',  'GANTI-DENGAN-SECRET-KEY-ANDA-YANG-AMAN-MIN-32-KARAKTER');
define('JWT_EXPIRE',  86400); // 24 jam (detik)

// Rate Limiting
define('RATE_LIMIT',  60);  // max request per menit
define('RATE_WINDOW', 60);  // window (detik)

// Paths
define('BASE_PATH',   dirname(__DIR__));
define('LOG_PATH',    BASE_PATH . '/logs/');
define('LOG_LEVEL',   'debug'); // debug | info | error

// Fee konfigurasi (dalam Rupiah)
define('SCAN_PAY_FEE',  0);      // fee per transaksi scan pay
define('MIN_AMOUNT',    100);    // minimal nominal pembayaran
define('MAX_AMOUNT',    50000000); // maksimal nominal pembayaran
