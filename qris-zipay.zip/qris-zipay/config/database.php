<?php
// ============================================================
// KONFIGURASI DATABASE (PDO - MySQL/SQLite)
// ============================================================

define('DB_DRIVER',   'mysql');   // mysql | sqlite
define('DB_HOST',     'localhost');
define('DB_PORT',     '3306');
define('DB_NAME',     'qris_zipay');
define('DB_USER',     'root');
define('DB_PASS',     '');
define('DB_CHARSET',  'utf8mb4');

// SQLite path (jika driver = sqlite)
define('DB_SQLITE_PATH', BASE_PATH . '/database/qris_zipay.sqlite');
