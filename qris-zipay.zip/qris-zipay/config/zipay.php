<?php
// ============================================================
// KONFIGURASI ZIPAY API
// ============================================================

define('ZIPAY_BASE_URL',    'https://api.zipay.co.id');
define('ZIPAY_TIMEOUT',     30);   // timeout cURL (detik)
define('ZIPAY_VERIFY_SSL',  true); // false untuk development/sandbox

// Default credentials (bisa di-override per merchant dari DB)
define('ZIPAY_USER_ID',      'YOUR_ZIPAY_USER_ID');
define('ZIPAY_PASSWORD',     'YOUR_ZIPAY_PASSWORD');
define('ZIPAY_MERCHANT_ID',  'YOUR_MERCHANT_ID');
define('ZIPAY_MERCHANT_KEY', 'YOUR_MERCHANT_KEY');
define('ZIPAY_CALLBACK_URL', APP_URL . '/public/callback.php');

// QR Code image (via API eksternal)
define('QR_IMAGE_API', 'https://api.qrserver.com/v1/create-qr-code/?size=280x280&data=');
