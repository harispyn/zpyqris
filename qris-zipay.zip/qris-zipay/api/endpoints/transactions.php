<?php
// ============================================================
// TRANSACTION CONTROLLER
// List, Detail, Callback handler
// ============================================================

class TransactionController {

    /**
     * GET /api/transactions?page=1&limit=20&type=scan_pay&status=success
     * Riwayat transaksi merchant
     */
    public static function list(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $page     = max(1, (int)($_GET['page']   ?? 1));
        $limit    = min(100, max(1, (int)($_GET['limit']  ?? 20)));
        $offset   = ($page - 1) * $limit;
        $type     = $_GET['type']   ?? '';
        $status   = $_GET['status'] ?? '';
        $dateFrom = $_GET['date_from'] ?? '';
        $dateTo   = $_GET['date_to']   ?? '';

        $where  = 'WHERE payer_merchant_id = ?';
        $params = [$merchant['id']];

        if (!empty($type)) {
            $allowed = ['scan_pay','receive','topup','refund'];
            if (in_array($type, $allowed)) {
                $where .= ' AND type = ?';
                $params[] = $type;
            }
        }

        if (!empty($status)) {
            $allowed = ['pending','processing','success','failed','expired'];
            if (in_array($status, $allowed)) {
                $where .= ' AND status = ?';
                $params[] = $status;
            }
        }

        if (!empty($dateFrom)) {
            $where .= ' AND DATE(created_at) >= ?';
            $params[] = $dateFrom;
        }

        if (!empty($dateTo)) {
            $where .= ' AND DATE(created_at) <= ?';
            $params[] = $dateTo;
        }

        // Total count
        $total = Database::fetchOne(
            "SELECT COUNT(*) as cnt FROM transactions {$where}",
            $params
        );

        // Ambil data dengan limit & offset
        $transactions = Database::fetchAll(
            "SELECT
                transaction_id, external_id, type,
                payee_merchant_name, payee_mid, payee_city,
                amount, fee, total_amount, status,
                note, paid_at, created_at
             FROM transactions {$where}
             ORDER BY created_at DESC
             LIMIT {$limit} OFFSET {$offset}",
            $params
        );

        // Format angka
        foreach ($transactions as &$trx) {
            $trx['amount']       = (float)$trx['amount'];
            $trx['fee']          = (float)$trx['fee'];
            $trx['total_amount'] = (float)$trx['total_amount'];
        }

        Response::success([
            'transactions' => $transactions,
            'pagination'   => [
                'page'        => $page,
                'limit'       => $limit,
                'total'       => (int)($total['cnt'] ?? 0),
                'total_pages' => (int)ceil(($total['cnt'] ?? 0) / $limit),
            ],
            'filters' => [
                'type'      => $type,
                'status'    => $status,
                'date_from' => $dateFrom,
                'date_to'   => $dateTo,
            ],
        ], 'Riwayat transaksi');
    }

    /**
     * GET /api/transactions/{id}
     * Detail transaksi
     */
    public static function detail(string $transactionId): void {
        $merchant = $_REQUEST['auth_merchant'];

        $trx = Database::fetchOne(
            'SELECT * FROM transactions WHERE transaction_id = ? AND payer_merchant_id = ?',
            [$transactionId, $merchant['id']]
        );

        if (!$trx) {
            Response::notFound('Transaksi tidak ditemukan');
        }

        Response::success([
            'transaction_id'     => $trx['transaction_id'],
            'external_id'        => $trx['external_id'],
            'zipay_uuid'         => $trx['zipay_uuid'],
            'type'               => $trx['type'],
            'payee'              => [
                'merchant_name'  => $trx['payee_merchant_name'],
                'mid'            => $trx['payee_mid'],
                'mpan'           => $trx['payee_mpan'],
                'city'           => $trx['payee_city'],
            ],
            'amount'             => (float)$trx['amount'],
            'fee'                => (float)$trx['fee'],
            'total_amount'       => (float)$trx['total_amount'],
            'status'             => $trx['status'],
            'qr_image_url'       => $trx['qr_image_url'],
            'note'               => $trx['note'],
            'paid_at'            => $trx['paid_at'],
            'expired_at'         => $trx['expired_at'],
            'created_at'         => $trx['created_at'],
            'response_data'      => $trx['response_data'] ? json_decode($trx['response_data'], true) : null,
        ], 'Detail transaksi');
    }

    /**
     * POST /callback (Webhook dari Zipay)
     * Tidak butuh JWT auth — diakses langsung oleh server Zipay
     */
    public static function callback(): void {
        $raw  = file_get_contents('php://input');
        $data = json_decode($raw, true) ?? [];

        Logger::info('Webhook diterima', ['data' => $data]);

        // Field yang dikirim Zipay
        $invoiceNumber   = $data['invoiceNumber']   ?? '';
        $externalId      = $data['externalId']      ?? '';
        $amount          = $data['amount']           ?? 0;
        $status          = strtoupper($data['status'] ?? '');
        $transactionDate = $data['transactionDate']  ?? '';

        if (empty($externalId) && empty($invoiceNumber)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Missing fields']);
            exit;
        }

        if ($status !== 'PAID') {
            Logger::info('Callback bukan PAID, diabaikan', ['status' => $status]);
            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'Ignored (not PAID)']);
            exit;
        }

        // Cari transaksi berdasarkan external_id
        $trx = Database::fetchOne(
            'SELECT * FROM transactions WHERE external_id = ?',
            [$externalId]
        );

        if (!$trx) {
            Logger::warning('Transaksi tidak ditemukan untuk callback', ['external_id' => $externalId]);
            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'Transaction not found (no action)']);
            exit;
        }

        if ($trx['status'] === 'success') {
            // Sudah diproses sebelumnya
            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'Already processed']);
            exit;
        }

        // Update status transaksi
        Database::execute(
            'UPDATE transactions SET status = "success", paid_at = NOW(), response_data = ? WHERE external_id = ?',
            [json_encode($data), $externalId]
        );

        // Jika tipe "receive" → credit saldo merchant
        if ($trx['type'] === 'receive') {
            $merchantId = $trx['payer_merchant_id'];
            if ($merchantId) {
                Database::beginTransaction();
                try {
                    $fresh  = Database::fetchOne('SELECT balance FROM merchants WHERE id = ?', [$merchantId]);
                    $before = (float)$fresh['balance'];
                    $after  = $before + (float)$trx['amount'];

                    Database::execute(
                        'UPDATE merchants SET balance = balance + ? WHERE id = ?',
                        [(float)$trx['amount'], $merchantId]
                    );

                    Database::execute(
                        'INSERT INTO balance_logs (merchant_id, transaction_id, type, amount, balance_before, balance_after, description)
                         VALUES (?, ?, "credit", ?, ?, ?, ?)',
                        [$merchantId, $trx['transaction_id'], (float)$trx['amount'], $before, $after, 'Pembayaran QRIS masuk dari Zipay - ' . $invoiceNumber]
                    );

                    Database::commit();
                    Logger::info('Saldo merchant di-credit via callback', ['merchant_id' => $merchantId, 'amount' => $trx['amount']]);

                } catch (Exception $e) {
                    Database::rollback();
                    Logger::error('Gagal credit saldo via callback', ['error' => $e->getMessage()]);
                }
            }
        }

        Logger::info('Callback diproses sukses', ['external_id' => $externalId, 'amount' => $amount]);

        http_response_code(200);
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Callback processed']);
        exit;
    }
}
