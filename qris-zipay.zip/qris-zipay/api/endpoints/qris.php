<?php
// ============================================================
// QRIS CONTROLLER
// ★ Scan Pay, Create QRIS, Status, Parse, Validate
// ============================================================

class QRISController {

    // ============================================================
    // ★ ENDPOINT UTAMA: POST /api/qris/scan-pay
    // ============================================================

    /**
     * Scan QRIS dan bayar menggunakan saldo merchant Zipay
     *
     * Request Body:
     * {
     *   "qr_string": "00020101...",   // QRIS string hasil scan kamera
     *   "amount":    50000,           // nominal (Rp), opsional jika QR dynamic ada amount
     *   "note":      "keterangan"     // opsional
     * }
     *
     * Response:
     * {
     *   "success": true,
     *   "data": {
     *     "transaction_id": "SPAY-20260302-XXXXX",
     *     "payee": { "merchant_name": "...", "mid": "...", "city": "..." },
     *     "amount": 50000,
     *     "fee": 0,
     *     "balance_before": 200000,
     *     "balance_after":  150000,
     *     "status": "success",
     *     "created_at": "..."
     *   }
     * }
     */
    public static function scanPay(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $body     = self::getBody();

        // ── 1. Validasi input ──────────────────────────────────
        $errors = [];
        if (empty($body['qr_string'])) {
            $errors[] = 'qr_string wajib diisi';
        }
        if (!empty($errors)) {
            Response::validationError($errors);
        }

        $qrString = trim($body['qr_string']);
        $note     = $body['note'] ?? '';

        // ── 2. Parse QRIS string ───────────────────────────────
        $qrData = QRISParser::parse($qrString);

        if (!$qrData['isValid']) {
            Response::error(
                'QRIS tidak valid: ' . implode(', ', $qrData['errors']),
                422
            );
        }

        // ── 3. Tentukan nominal ────────────────────────────────
        $amount = 0;

        if (!empty($body['amount'])) {
            $amount = (float)$body['amount'];
        } elseif (!empty($qrData['amount'])) {
            $amount = (float)$qrData['amount'];
        }

        if ($amount <= 0) {
            Response::validationError(['amount wajib diisi karena QR bersifat statis (tidak ada nominal)']);
        }

        if ($amount < MIN_AMOUNT) {
            Response::error('Nominal minimal adalah Rp ' . number_format(MIN_AMOUNT, 0, ',', '.'), 422);
        }

        if ($amount > MAX_AMOUNT) {
            Response::error('Nominal maksimal adalah Rp ' . number_format(MAX_AMOUNT, 0, ',', '.'), 422);
        }

        // ── 4. Hitung fee & total ──────────────────────────────
        $fee         = SCAN_PAY_FEE;
        $totalAmount = $amount + $fee;

        // ── 5. Cek saldo merchant ──────────────────────────────
        $merchantBalance = (float)$merchant['balance'];

        if ($merchantBalance < $totalAmount) {
            Response::error(
                'Saldo tidak cukup. Saldo Anda: Rp ' . number_format($merchantBalance, 0, ',', '.') .
                ', dibutuhkan: Rp ' . number_format($totalAmount, 0, ',', '.'),
                400
            );
        }

        // ── 6. Buat transaction ID unik ────────────────────────
        $transactionId = 'SPAY-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));
        $externalId    = 'EXT-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));

        // ── 7. BEGIN DB TRANSACTION (atomic) ──────────────────
        Database::beginTransaction();

        try {
            $balanceBefore = $merchantBalance;
            $balanceAfter  = $merchantBalance - $totalAmount;

            // ── 7a. Insert transaksi (status: processing) ──────
            Database::execute(
                'INSERT INTO transactions (
                    transaction_id, external_id,
                    payer_merchant_id,
                    payee_merchant_name, payee_mid, payee_mpan, payee_city,
                    type, amount, fee, total_amount, status,
                    qr_string, note, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, "scan_pay", ?, ?, ?, "processing", ?, ?, NOW())',
                [
                    $transactionId,
                    $externalId,
                    $merchant['id'],
                    $qrData['merchantName'] ?? 'Unknown',
                    $qrData['mid']          ?? '',
                    $qrData['mpan']         ?? '',
                    $qrData['merchantCity'] ?? '',
                    $amount,
                    $fee,
                    $totalAmount,
                    $qrString,
                    $note,
                ]
            );

            // ── 7b. Deduct saldo merchant ──────────────────────
            $affected = Database::execute(
                'UPDATE merchants SET balance = balance - ? WHERE id = ? AND balance >= ?',
                [$totalAmount, $merchant['id'], $totalAmount]
            );

            if ($affected === 0) {
                throw new Exception('Gagal deduct saldo (race condition atau saldo tidak cukup)');
            }

            // ── 7c. Catat balance log ──────────────────────────
            Database::execute(
                'INSERT INTO balance_logs (
                    merchant_id, transaction_id, type, amount,
                    balance_before, balance_after, description
                ) VALUES (?, ?, "debit", ?, ?, ?, ?)',
                [
                    $merchant['id'],
                    $transactionId,
                    $totalAmount,
                    $balanceBefore,
                    $balanceAfter,
                    'Scan Pay: ' . ($qrData['merchantName'] ?? 'Unknown') . ' - ' . $transactionId,
                ]
            );

            // ── 7d. Proses pembayaran ke Zipay (jika terkonfigurasi) ──
            $zipayResponse = null;
            $zipayStatus   = 'skipped';

            if (!empty($merchant['zipay_merchant_id'])) {
                try {
                    $zipay = new ZipayService([
                        'zipay_user_id'      => $merchant['zipay_user_id'],
                        'zipay_password'     => $merchant['zipay_password'],
                        'zipay_merchant_id'  => $merchant['zipay_merchant_id'],
                        'zipay_merchant_key' => $merchant['zipay_merchant_key'],
                        'db_merchant_id'     => $merchant['id'],
                    ]);

                    // Buat QRIS dinamis untuk settlement ke merchant target
                    // Catatan: Zipay tidak memiliki endpoint CPM/scan-pay publik
                    // Ini adalah flow alternatif: create QRIS + inquiry
                    // Untuk production, gunakan endpoint yang dikonfirmasi Zipay support
                    $createResp = $zipay->createQRIS((int)$amount, $externalId);
                    $zipayResponse = $createResp;

                    if (!empty($createResp['data']['uuid'])) {
                        $zipayStatus = 'initiated';
                        // Simpan UUID untuk tracking
                        Database::execute(
                            'UPDATE transactions SET zipay_uuid = ?, response_data = ? WHERE transaction_id = ?',
                            [$createResp['data']['uuid'], json_encode($createResp), $transactionId]
                        );
                    }

                } catch (Exception $ze) {
                    // Jangan batalkan transaksi internal jika Zipay gagal
                    Logger::warning('Zipay call gagal (transaksi internal tetap lanjut)', [
                        'error' => $ze->getMessage(),
                        'transaction_id' => $transactionId,
                    ]);
                    $zipayStatus = 'zipay_error';
                }
            }

            // ── 7e. Update status transaksi → success ──────────
            Database::execute(
                'UPDATE transactions SET
                    status = "success",
                    response_data = ?,
                    paid_at = NOW()
                 WHERE transaction_id = ?',
                [
                    json_encode([
                        'zipay_status'   => $zipayStatus,
                        'zipay_response' => $zipayResponse,
                    ]),
                    $transactionId,
                ]
            );

            // ── 8. COMMIT ──────────────────────────────────────
            Database::commit();

            Logger::info('Scan Pay sukses', [
                'transaction_id' => $transactionId,
                'merchant_id'    => $merchant['id'],
                'amount'         => $amount,
                'payee'          => $qrData['merchantName'],
            ]);

            // ── 9. Return response ──────────────────────────────
            Response::success([
                'transaction_id' => $transactionId,
                'external_id'    => $externalId,
                'type'           => 'scan_pay',
                'payee'          => [
                    'merchant_name' => $qrData['merchantName'],
                    'mid'           => $qrData['mid'],
                    'mpan'          => $qrData['mpan'],
                    'city'          => $qrData['merchantCity'],
                    'acquirer'      => $qrData['acquirer'],
                ],
                'amount'         => $amount,
                'fee'            => $fee,
                'total_deducted' => $totalAmount,
                'balance_before' => $balanceBefore,
                'balance_after'  => $balanceAfter,
                'status'         => 'success',
                'zipay_status'   => $zipayStatus,
                'note'           => $note,
                'created_at'     => date('Y-m-d H:i:s'),
            ], 'Pembayaran berhasil');

        } catch (Exception $e) {
            // ── ROLLBACK jika ada error ────────────────────────
            Database::rollback();

            Logger::error('Scan Pay gagal', [
                'transaction_id' => $transactionId,
                'error'          => $e->getMessage(),
                'merchant_id'    => $merchant['id'],
            ]);

            // Update status transaksi → failed (jika sudah insert)
            try {
                Database::execute(
                    'UPDATE transactions SET status = "failed" WHERE transaction_id = ?',
                    [$transactionId]
                );
            } catch (Exception $ignored) {}

            Response::error('Pembayaran gagal: ' . $e->getMessage(), 500);
        }
    }

    // ============================================================
    // POST /api/qris/create — Buat QR untuk terima pembayaran
    // ============================================================

    public static function createQRIS(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $body     = self::getBody();

        // Validasi
        $errors = [];
        if (empty($body['amount'])) $errors[] = 'amount wajib diisi';
        if ((float)($body['amount'] ?? 0) < MIN_AMOUNT) $errors[] = 'amount minimal Rp ' . number_format(MIN_AMOUNT, 0, ',', '.');
        if (!empty($errors)) Response::validationError($errors);

        $amount     = (int)$body['amount'];
        $note       = $body['note'] ?? '';
        $externalId = $body['external_id'] ?? ('INV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8)));

        // Cek konfigurasi Zipay
        if (empty($merchant['zipay_merchant_id'])) {
            // Buat QR internal (tanpa Zipay)
            $qrString = QRISParser::generate(
                'INTERNAL-' . $merchant['id'],
                str_pad((string)$merchant['id'], 19, '0', STR_PAD_LEFT),
                strtoupper($merchant['merchant_name']),
                'INDONESIA',
                $amount
            );

            $transactionId = 'RCV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));

            Database::execute(
                'INSERT INTO transactions (
                    transaction_id, external_id, payer_merchant_id,
                    type, amount, fee, total_amount, status,
                    qr_string, qr_image_url, note
                ) VALUES (?, ?, ?, "receive", ?, 0, ?, "pending", ?, ?, ?)',
                [
                    $transactionId,
                    $externalId,
                    $merchant['id'],
                    $amount,
                    $amount,
                    $qrString,
                    QR_IMAGE_API . urlencode($qrString),
                    $note,
                ]
            );

            Response::success([
                'transaction_id' => $transactionId,
                'external_id'    => $externalId,
                'qr_string'      => $qrString,
                'qr_image_url'   => QR_IMAGE_API . urlencode($qrString),
                'amount'         => $amount,
                'status'         => 'pending',
                'note'           => $note,
                'source'         => 'internal',
                'expired_at'     => date('Y-m-d H:i:s', time() + 3600),
            ], 'QR QRIS berhasil dibuat');
        }

        // Buat QR via Zipay
        $zipay = new ZipayService([
            'zipay_user_id'      => $merchant['zipay_user_id'],
            'zipay_password'     => $merchant['zipay_password'],
            'zipay_merchant_id'  => $merchant['zipay_merchant_id'],
            'zipay_merchant_key' => $merchant['zipay_merchant_key'],
            'db_merchant_id'     => $merchant['id'],
        ]);

        $response = $zipay->createQRIS($amount, $externalId);

        if (empty($response['data'])) {
            Response::error('Gagal membuat QR via Zipay: ' . ($response['message'] ?? 'Unknown'), 502);
        }

        $data          = $response['data'];
        $transactionId = 'RCV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));
        $qrString      = $data['qrString'] ?? '';
        $uuid          = $data['uuid']     ?? '';

        Database::execute(
            'INSERT INTO transactions (
                transaction_id, external_id, zipay_uuid, payer_merchant_id,
                type, amount, fee, total_amount, status,
                qr_string, qr_image_url, note, response_data
            ) VALUES (?, ?, ?, ?, "receive", ?, 0, ?, "pending", ?, ?, ?, ?)',
            [
                $transactionId,
                $externalId,
                $uuid,
                $merchant['id'],
                $amount,
                $amount,
                $qrString,
                QR_IMAGE_API . urlencode($qrString),
                $note,
                json_encode($data),
            ]
        );

        Response::success([
            'transaction_id' => $transactionId,
            'external_id'    => $externalId,
            'zipay_uuid'     => $uuid,
            'qr_string'      => $qrString,
            'qr_image_url'   => QR_IMAGE_API . urlencode($qrString),
            'amount'         => $amount,
            'status'         => 'pending',
            'note'           => $note,
            'source'         => 'zipay',
            'expired_at'     => $data['expiredAt'] ?? date('Y-m-d H:i:s', time() + 3600),
        ], 'QR QRIS berhasil dibuat via Zipay');
    }

    // ============================================================
    // POST /api/qris/status — Cek status transaksi
    // ============================================================

    public static function checkStatus(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $body     = self::getBody();

        if (empty($body['transaction_id']) && empty($body['uuid'])) {
            Response::validationError(['transaction_id atau uuid wajib diisi']);
        }

        // Cari transaksi di DB kita
        if (!empty($body['transaction_id'])) {
            $trx = Database::fetchOne(
                'SELECT * FROM transactions WHERE transaction_id = ? AND payer_merchant_id = ?',
                [$body['transaction_id'], $merchant['id']]
            );
        } else {
            $trx = Database::fetchOne(
                'SELECT * FROM transactions WHERE zipay_uuid = ? AND payer_merchant_id = ?',
                [$body['uuid'], $merchant['id']]
            );
        }

        if (!$trx) {
            Response::notFound('Transaksi tidak ditemukan');
        }

        // Jika punya UUID Zipay dan status masih pending, cek ke Zipay
        if ($trx['zipay_uuid'] && in_array($trx['status'], ['pending', 'processing'])) {
            if (!empty($merchant['zipay_merchant_id'])) {
                try {
                    $zipay    = new ZipayService([
                        'zipay_user_id'      => $merchant['zipay_user_id'],
                        'zipay_password'     => $merchant['zipay_password'],
                        'zipay_merchant_id'  => $merchant['zipay_merchant_id'],
                        'zipay_merchant_key' => $merchant['zipay_merchant_key'],
                        'db_merchant_id'     => $merchant['id'],
                    ]);
                    $zipayResp = $zipay->inquiryStatus($trx['zipay_uuid']);

                    if (!empty($zipayResp['data']['status'])) {
                        $zipayStatus = strtolower($zipayResp['data']['status']);

                        if ($zipayStatus === 'paid' || $zipayStatus === 'success') {
                            Database::execute(
                                'UPDATE transactions SET status = "success", paid_at = NOW() WHERE transaction_id = ?',
                                [$trx['transaction_id']]
                            );
                            $trx['status']  = 'success';
                            $trx['paid_at'] = date('Y-m-d H:i:s');
                        } elseif ($zipayStatus === 'expired') {
                            Database::execute(
                                'UPDATE transactions SET status = "expired" WHERE transaction_id = ?',
                                [$trx['transaction_id']]
                            );
                            $trx['status'] = 'expired';
                        }
                    }
                } catch (Exception $e) {
                    Logger::warning('Zipay inquiry gagal', ['error' => $e->getMessage()]);
                }
            }
        }

        Response::success([
            'transaction_id'    => $trx['transaction_id'],
            'external_id'       => $trx['external_id'],
            'type'              => $trx['type'],
            'payee_merchant'    => $trx['payee_merchant_name'],
            'amount'            => (float)$trx['amount'],
            'fee'               => (float)$trx['fee'],
            'total_amount'      => (float)$trx['total_amount'],
            'status'            => $trx['status'],
            'note'              => $trx['note'],
            'paid_at'           => $trx['paid_at'],
            'created_at'        => $trx['created_at'],
        ], 'Status transaksi');
    }

    // ============================================================
    // POST /api/qris/parse — Parse QRIS string
    // ============================================================

    public static function parseQRIS(): void {
        $body = self::getBody();

        if (empty($body['qr_string'])) {
            Response::validationError(['qr_string wajib diisi']);
        }

        $result = QRISParser::parse($body['qr_string']);

        Response::success([
            'isValid'       => $result['isValid'],
            'isDynamic'     => $result['isDynamic'],
            'isStatic'      => $result['isStatic'],
            'merchantName'  => $result['merchantName'],
            'merchantCity'  => $result['merchantCity'],
            'mid'           => $result['mid'],
            'mpan'          => $result['mpan'],
            'criteria'      => $result['criteria'],
            'acquirer'      => $result['acquirer'],
            'amount'        => $result['amount'],
            'amountFormatted' => $result['amount'] ? QRISParser::formatAmount((float)$result['amount']) : null,
            'currency'      => $result['currency'],
            'countryCode'   => $result['countryCode'],
            'mcc'           => $result['mcc'],
            'crcValid'      => $result['crcValid'],
            'errors'        => $result['errors'],
        ], 'Parse QRIS berhasil');
    }

    // ============================================================
    // POST /api/qris/validate — Validasi QRIS (tanpa auth)
    // ============================================================

    public static function validateQRIS(): void {
        $body = self::getBody();

        if (empty($body['qr_string'])) {
            Response::validationError(['qr_string wajib diisi']);
        }

        $result  = QRISParser::parse($body['qr_string']);
        $crcOnly = QRISParser::validateCRC($body['qr_string']);

        $warnings = [];
        if ($result['isStatic']) {
            $warnings[] = 'QR bersifat statis, nominal ditentukan oleh pembayar';
        }
        if (empty($result['amount']) && $result['isDynamic']) {
            $warnings[] = 'QR dinamis tetapi tidak mencantumkan nominal';
        }

        Response::success([
            'isValid'    => $result['isValid'],
            'crcValid'   => $crcOnly,
            'isDynamic'  => $result['isDynamic'],
            'isStatic'   => $result['isStatic'],
            'errors'     => $result['errors'],
            'warnings'   => $warnings,
        ], $result['isValid'] ? 'QRIS valid' : 'QRIS tidak valid');
    }

    /**
     * Ambil request body (JSON atau POST)
     */
    private static function getBody(): array {
        $raw  = file_get_contents('php://input');
        $body = json_decode($raw, true) ?? [];
        if (empty($body) && !empty($_POST)) {
            $body = $_POST;
        }
        return $body;
    }
}
