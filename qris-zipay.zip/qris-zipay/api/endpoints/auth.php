<?php
// ============================================================
// AUTH CONTROLLER
// Login, Register, Refresh Token
// ============================================================

class AuthController {

    /**
     * POST /api/auth/register
     * Daftar merchant baru
     */
    public static function register(): void {
        $body = self::getBody();

        // Validasi input
        $errors = [];
        if (empty($body['merchant_name'])) $errors[] = 'merchant_name wajib diisi';
        if (empty($body['email']))         $errors[] = 'email wajib diisi';
        if (empty($body['password']))      $errors[] = 'password wajib diisi';
        if (strlen($body['password'] ?? '') < 6) $errors[] = 'password minimal 6 karakter';
        if (!filter_var($body['email'] ?? '', FILTER_VALIDATE_EMAIL)) $errors[] = 'format email tidak valid';

        if (!empty($errors)) {
            Response::validationError($errors);
        }

        // Cek email sudah terdaftar
        $existing = Database::fetchOne('SELECT id FROM merchants WHERE email = ?', [$body['email']]);
        if ($existing) {
            Response::error('Email sudah terdaftar', 409);
        }

        // Generate API key unik
        $apiKey = bin2hex(random_bytes(32));

        // Hash password
        $hashedPassword = password_hash($body['password'], PASSWORD_BCRYPT);

        // Insert merchant
        $merchantId = Database::insert(
            'INSERT INTO merchants (
                merchant_name, email, password, phone,
                zipay_user_id, zipay_password,
                zipay_merchant_id, zipay_merchant_key,
                api_key, balance, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0.00, "active")',
            [
                $body['merchant_name'],
                $body['email'],
                $hashedPassword,
                $body['phone'] ?? null,
                $body['zipay_user_id']      ?? null,
                $body['zipay_password']     ?? null,
                $body['zipay_merchant_id']  ?? null,
                $body['zipay_merchant_key'] ?? null,
                $apiKey,
            ]
        );

        Logger::info('Merchant baru terdaftar', ['merchant_id' => $merchantId, 'email' => $body['email']]);

        Response::success([
            'merchant_id'   => (int)$merchantId,
            'merchant_name' => $body['merchant_name'],
            'email'         => $body['email'],
            'api_key'       => $apiKey,
        ], 'Registrasi berhasil. Simpan API Key Anda.', 201);
    }

    /**
     * POST /api/auth/login
     * Login → return JWT token
     */
    public static function login(): void {
        $body = self::getBody();

        if (empty($body['email']) || empty($body['password'])) {
            Response::validationError(['email dan password wajib diisi']);
        }

        // Cari merchant
        $merchant = Database::fetchOne(
            'SELECT id, merchant_name, email, password, api_key, balance, status
             FROM merchants WHERE email = ?',
            [$body['email']]
        );

        if (!$merchant) {
            Response::unauthorized('Email atau password salah');
        }

        if ($merchant['status'] !== 'active') {
            Response::forbidden('Akun Anda tidak aktif. Hubungi admin.');
        }

        if (!password_verify($body['password'], $merchant['password'])) {
            Response::unauthorized('Email atau password salah');
        }

        // Generate JWT
        $token = JWTHelper::encode([
            'merchant_id'   => $merchant['id'],
            'merchant_name' => $merchant['merchant_name'],
            'email'         => $merchant['email'],
        ]);

        Logger::info('Login berhasil', ['merchant_id' => $merchant['id']]);

        Response::success([
            'token'         => $token,
            'token_type'    => 'Bearer',
            'expires_in'    => JWT_EXPIRE,
            'api_key'       => $merchant['api_key'],
            'merchant_name' => $merchant['merchant_name'],
            'email'         => $merchant['email'],
            'balance'       => (float)$merchant['balance'],
        ], 'Login berhasil');
    }

    /**
     * GET /api/auth/me
     * Info merchant yang sedang login
     * Requires: JWT atau X-API-Key
     */
    public static function me(): void {
        $merchant = $_REQUEST['auth_merchant'];

        Response::success([
            'merchant_id'       => (int)$merchant['id'],
            'merchant_name'     => $merchant['merchant_name'],
            'email'             => $merchant['email'],
            'phone'             => $merchant['phone'],
            'balance'           => (float)$merchant['balance'],
            'has_zipay_config'  => !empty($merchant['zipay_merchant_id']),
            'status'            => $merchant['status'],
        ], 'Info merchant');
    }

    /**
     * POST /api/auth/update-zipay
     * Update kredensial Zipay merchant
     * Requires: JWT atau X-API-Key
     */
    public static function updateZipay(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $body     = self::getBody();

        $errors = [];
        if (empty($body['zipay_user_id']))      $errors[] = 'zipay_user_id wajib diisi';
        if (empty($body['zipay_password']))     $errors[] = 'zipay_password wajib diisi';
        if (empty($body['zipay_merchant_id']))  $errors[] = 'zipay_merchant_id wajib diisi';
        if (empty($body['zipay_merchant_key'])) $errors[] = 'zipay_merchant_key wajib diisi';

        if (!empty($errors)) {
            Response::validationError($errors);
        }

        Database::execute(
            'UPDATE merchants SET
                zipay_user_id = ?, zipay_password = ?,
                zipay_merchant_id = ?, zipay_merchant_key = ?
             WHERE id = ?',
            [
                $body['zipay_user_id'],
                $body['zipay_password'],
                $body['zipay_merchant_id'],
                $body['zipay_merchant_key'],
                $merchant['id'],
            ]
        );

        // Hapus token Zipay lama agar login ulang
        Database::execute('DELETE FROM zipay_tokens WHERE merchant_id = ?', [$merchant['id']]);

        Logger::info('Zipay credentials updated', ['merchant_id' => $merchant['id']]);

        Response::success(null, 'Kredensial Zipay berhasil diperbarui');
    }

    /**
     * Ambil request body (JSON)
     */
    private static function getBody(): array {
        $raw  = file_get_contents('php://input');
        $body = json_decode($raw, true) ?? [];

        // Support form data juga
        if (empty($body) && !empty($_POST)) {
            $body = $_POST;
        }

        return $body;
    }
}
