<?php
// ============================================================
// BALANCE CONTROLLER
// Cek saldo, log mutasi, sync Zipay
// ============================================================

class BalanceController {

    /**
     * GET /api/balance
     * Cek saldo merchant + info dari Zipay
     */
    public static function check(): void {
        $merchant = $_REQUEST['auth_merchant'];

        // Saldo dari DB kita
        $fresh = Database::fetchOne(
            'SELECT balance FROM merchants WHERE id = ?',
            [$merchant['id']]
        );

        $balance = (float)($fresh['balance'] ?? 0);

        // Info Zipay (jika terkonfigurasi)
        $zipayInfo = null;
        if (!empty($merchant['zipay_merchant_id'])) {
            try {
                $zipay     = new ZipayService([
                    'zipay_user_id'      => $merchant['zipay_user_id'],
                    'zipay_password'     => $merchant['zipay_password'],
                    'zipay_merchant_id'  => $merchant['zipay_merchant_id'],
                    'zipay_merchant_key' => $merchant['zipay_merchant_key'],
                    'db_merchant_id'     => $merchant['id'],
                ]);
                $infoResp  = $zipay->getMerchantInfo();
                $zipayInfo = $infoResp['data'] ?? null;
            } catch (Exception $e) {
                Logger::warning('Gagal ambil info Zipay untuk balance', ['error' => $e->getMessage()]);
            }
        }

        // Statistik transaksi
        $stats = Database::fetchOne(
            'SELECT
                COUNT(*) as total_trx,
                SUM(CASE WHEN status = "success" AND type = "scan_pay" THEN total_amount ELSE 0 END) as total_keluar,
                SUM(CASE WHEN status = "success" AND type = "receive"  THEN amount       ELSE 0 END) as total_masuk,
                SUM(CASE WHEN status = "success" AND type = "topup"    THEN amount       ELSE 0 END) as total_topup
             FROM transactions WHERE payer_merchant_id = ?',
            [$merchant['id']]
        );

        Response::success([
            'merchant_name'   => $merchant['merchant_name'],
            'balance'         => $balance,
            'balance_formatted' => 'Rp ' . number_format($balance, 0, ',', '.'),
            'zipay_info'      => $zipayInfo,
            'statistics'      => [
                'total_transactions' => (int)($stats['total_trx'] ?? 0),
                'total_keluar'       => (float)($stats['total_keluar'] ?? 0),
                'total_masuk'        => (float)($stats['total_masuk'] ?? 0),
                'total_topup'        => (float)($stats['total_topup'] ?? 0),
            ],
        ], 'Info saldo');
    }

    /**
     * GET /api/balance/logs?page=1&limit=20
     * Riwayat mutasi saldo
     */
    public static function logs(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $page     = max(1, (int)($_GET['page']  ?? 1));
        $limit    = min(100, max(1, (int)($_GET['limit'] ?? 20)));
        $offset   = ($page - 1) * $limit;
        $type     = $_GET['type'] ?? ''; // debit | credit

        $where  = 'WHERE merchant_id = ?';
        $params = [$merchant['id']];

        if ($type === 'debit' || $type === 'credit') {
            $where  .= ' AND type = ?';
            $params[] = $type;
        }

        $total = Database::fetchOne(
            "SELECT COUNT(*) as cnt FROM balance_logs {$where}",
            $params
        );

        $logs = Database::fetchAll(
            "SELECT id, transaction_id, type, amount, balance_before, balance_after, description, created_at
             FROM balance_logs {$where}
             ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}",
            $params
        );

        // Format amount
        foreach ($logs as &$log) {
            $log['amount']         = (float)$log['amount'];
            $log['balance_before'] = (float)$log['balance_before'];
            $log['balance_after']  = (float)$log['balance_after'];
        }

        Response::success([
            'logs'       => $logs,
            'pagination' => [
                'page'        => $page,
                'limit'       => $limit,
                'total'       => (int)($total['cnt'] ?? 0),
                'total_pages' => (int)ceil(($total['cnt'] ?? 0) / $limit),
            ],
        ], 'Log mutasi saldo');
    }

    /**
     * POST /api/balance/topup
     * Topup saldo (manual - untuk admin/testing)
     * Di production: integrasikan dengan payment gateway
     */
    public static function topup(): void {
        $merchant = $_REQUEST['auth_merchant'];
        $body     = self::getBody();

        $amount = (float)($body['amount'] ?? 0);
        $note   = $body['note'] ?? 'Topup saldo';

        if ($amount <= 0) {
            Response::validationError(['amount harus lebih dari 0']);
        }

        $transactionId = 'TOPUP-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));

        Database::beginTransaction();
        try {
            // Ambil saldo sekarang
            $fresh  = Database::fetchOne('SELECT balance FROM merchants WHERE id = ? FOR UPDATE', [$merchant['id']]);
            $before = (float)$fresh['balance'];
            $after  = $before + $amount;

            // Update saldo
            Database::execute(
                'UPDATE merchants SET balance = balance + ? WHERE id = ?',
                [$amount, $merchant['id']]
            );

            // Catat balance log
            Database::execute(
                'INSERT INTO balance_logs (merchant_id, transaction_id, type, amount, balance_before, balance_after, description)
                 VALUES (?, ?, "credit", ?, ?, ?, ?)',
                [$merchant['id'], $transactionId, $amount, $before, $after, $note]
            );

            // Catat transaksi
            Database::execute(
                'INSERT INTO transactions (transaction_id, payer_merchant_id, type, amount, fee, total_amount, status, note)
                 VALUES (?, ?, "topup", ?, 0, ?, "success", ?)',
                [$transactionId, $merchant['id'], $amount, $amount, $note]
            );

            Database::commit();

            Response::success([
                'transaction_id' => $transactionId,
                'amount'         => $amount,
                'balance_before' => $before,
                'balance_after'  => $after,
            ], 'Topup berhasil');

        } catch (Exception $e) {
            Database::rollback();
            Response::error('Topup gagal: ' . $e->getMessage(), 500);
        }
    }

    /**
     * POST /api/balance/sync
     * Sync saldo dari Zipay (jika Zipay punya endpoint saldo)
     */
    public static function syncFromZipay(): void {
        $merchant = $_REQUEST['auth_merchant'];

        if (empty($merchant['zipay_merchant_id'])) {
            Response::error('Konfigurasi Zipay belum diisi', 400);
        }

        $zipay = new ZipayService([
            'zipay_user_id'      => $merchant['zipay_user_id'],
            'zipay_password'     => $merchant['zipay_password'],
            'zipay_merchant_id'  => $merchant['zipay_merchant_id'],
            'zipay_merchant_key' => $merchant['zipay_merchant_key'],
            'db_merchant_id'     => $merchant['id'],
        ]);

        $info = $zipay->getMerchantInfo();

        Response::success([
            'zipay_info'   => $info['data'] ?? null,
            'sync_success' => !empty($info['data']),
        ], 'Sync dari Zipay selesai');
    }

    private static function getBody(): array {
        $raw  = file_get_contents('php://input');
        $body = json_decode($raw, true) ?? [];
        if (empty($body) && !empty($_POST)) $body = $_POST;
        return $body;
    }
}
