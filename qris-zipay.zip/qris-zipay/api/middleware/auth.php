<?php
// ============================================================
// AUTH MIDDLEWARE
// ============================================================

class AuthMiddleware {

    /**
     * Validasi JWT token dari Authorization header
     * Set $_REQUEST['auth_merchant'] jika valid
     */
    public static function jwtAuth(): void {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

        if (empty($authHeader) || !str_starts_with($authHeader, 'Bearer ')) {
            Response::unauthorized('Token tidak ditemukan. Gunakan Authorization: Bearer {token}');
        }

        $token   = substr($authHeader, 7);
        $payload = JWTHelper::decode($token);

        if (!$payload) {
            Response::unauthorized('Token tidak valid atau sudah expired');
        }

        // Load merchant dari DB berdasarkan merchant_id di payload
        $merchant = Database::fetchOne(
            'SELECT id, merchant_name, email, phone,
                    zipay_user_id, zipay_password,
                    zipay_merchant_id, zipay_merchant_key,
                    api_key, balance, status
             FROM merchants WHERE id = ? AND status = "active"',
            [$payload['merchant_id']]
        );

        if (!$merchant) {
            Response::unauthorized('Merchant tidak ditemukan atau tidak aktif');
        }

        // Simpan ke request global
        $_REQUEST['auth_merchant'] = $merchant;
        $_REQUEST['auth_payload']  = $payload;
    }

    /**
     * Validasi API Key dari header X-API-Key
     * Set $_REQUEST['auth_merchant'] jika valid
     */
    public static function apiKeyAuth(): void {
        $apiKey = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? '';

        if (empty($apiKey)) {
            Response::unauthorized('API Key tidak ditemukan. Gunakan header X-API-Key');
        }

        $merchant = Database::fetchOne(
            'SELECT id, merchant_name, email, phone,
                    zipay_user_id, zipay_password,
                    zipay_merchant_id, zipay_merchant_key,
                    api_key, balance, status
             FROM merchants WHERE api_key = ? AND status = "active"',
            [$apiKey]
        );

        if (!$merchant) {
            Response::unauthorized('API Key tidak valid atau merchant tidak aktif');
        }

        $_REQUEST['auth_merchant'] = $merchant;
    }

    /**
     * Rate limiter berdasarkan merchant ID + endpoint
     * Menggunakan file-based counter (sederhana, tanpa Redis)
     */
    public static function rateLimiter(string $endpoint = ''): void {
        $merchant  = $_REQUEST['auth_merchant'] ?? null;
        $key       = $merchant ? $merchant['api_key'] : ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $endpoint  = $endpoint ?: ($_SERVER['REQUEST_URI'] ?? '/');

        $cacheFile = LOG_PATH . 'ratelimit_' . md5($key . $endpoint) . '.json';
        $now       = time();
        $windowStart = $now - RATE_WINDOW;

        // Baca data rate limit
        $data = [];
        if (file_exists($cacheFile)) {
            $data = json_decode(file_get_contents($cacheFile), true) ?? [];
        }

        // Hapus request di luar window
        $data = array_filter($data, fn($ts) => $ts > $windowStart);
        $data = array_values($data);

        if (count($data) >= RATE_LIMIT) {
            Response::tooManyRequests(
                'Rate limit exceeded. Maksimal ' . RATE_LIMIT . ' request per ' . RATE_WINDOW . ' detik.'
            );
        }

        // Tambah request saat ini
        $data[] = $now;
        file_put_contents($cacheFile, json_encode($data), LOCK_EX);
    }

    /**
     * Set CORS headers + handle preflight
     */
    public static function cors(): void {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
        header('Access-Control-Max-Age: 3600');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(204);
            exit;
        }
    }
}
