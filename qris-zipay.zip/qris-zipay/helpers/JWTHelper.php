<?php
// ============================================================
// JWT HELPER (tanpa library eksternal)
// ============================================================

class JWTHelper {

    /**
     * Encode payload menjadi JWT token
     */
    public static function encode(array $payload): string {
        $header = self::base64UrlEncode(json_encode([
            'alg' => 'HS256',
            'typ' => 'JWT',
        ]));

        $payload['iat'] = time();
        $payload['exp'] = time() + JWT_EXPIRE;

        $payloadEncoded = self::base64UrlEncode(json_encode($payload));

        $signature = hash_hmac(
            'sha256',
            "{$header}.{$payloadEncoded}",
            JWT_SECRET,
            true
        );

        return "{$header}.{$payloadEncoded}." . self::base64UrlEncode($signature);
    }

    /**
     * Decode dan verifikasi JWT token
     * Return payload array atau null jika invalid/expired
     */
    public static function decode(string $token): ?array {
        $parts = explode('.', $token);

        if (count($parts) !== 3) {
            return null;
        }

        [$headerB64, $payloadB64, $sigB64] = $parts;

        // Verifikasi signature
        $expectedSig = hash_hmac(
            'sha256',
            "{$headerB64}.{$payloadB64}",
            JWT_SECRET,
            true
        );

        if (!hash_equals(self::base64UrlEncode($expectedSig), $sigB64)) {
            return null;
        }

        // Decode payload
        $payload = json_decode(self::base64UrlDecode($payloadB64), true);

        if (!$payload) {
            return null;
        }

        // Cek expiry
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return null; // token expired
        }

        return $payload;
    }

    /**
     * Base64 URL encode (tanpa padding)
     */
    private static function base64UrlEncode(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Base64 URL decode
     */
    private static function base64UrlDecode(string $data): string {
        return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4));
    }
}
