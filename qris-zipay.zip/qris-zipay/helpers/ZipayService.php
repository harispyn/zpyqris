<?php
// ============================================================
// ZIPAY SERVICE - Integrasi API Zipay
// ============================================================

class ZipayService {

    private string $userId;
    private string $password;
    private string $merchantId;
    private string $merchantKey;
    private int    $dbMerchantId; // ID merchant di DB kita

    public function __construct(array $config) {
        $this->userId       = $config['zipay_user_id']      ?? ZIPAY_USER_ID;
        $this->password     = $config['zipay_password']     ?? ZIPAY_PASSWORD;
        $this->merchantId   = $config['zipay_merchant_id']  ?? ZIPAY_MERCHANT_ID;
        $this->merchantKey  = $config['zipay_merchant_key'] ?? ZIPAY_MERCHANT_KEY;
        $this->dbMerchantId = (int)($config['db_merchant_id'] ?? 0);
    }

    // ============================================================
    // AUTHENTICATION
    // ============================================================

    /**
     * Login ke Zipay → return Bearer token
     * POST /auth/login
     */
    public function login(): string {
        $response = $this->callAPI('/auth/login', [
            'userId'   => $this->userId,
            'password' => $this->password,
        ], '', false); // tidak butuh token untuk login

        if (!isset($response['data']['token'])) {
            Logger::error('Zipay login gagal', ['response' => $response]);
            throw new Exception('Zipay login gagal: ' . ($response['message'] ?? 'Unknown error'));
        }

        $token     = $response['data']['token'];
        $expiresAt = date('Y-m-d H:i:s', time() + 3600); // asumsi expire 1 jam

        // Simpan token ke DB
        if ($this->dbMerchantId > 0) {
            $existing = Database::fetchOne(
                'SELECT id FROM zipay_tokens WHERE merchant_id = ?',
                [$this->dbMerchantId]
            );

            if ($existing) {
                Database::execute(
                    'UPDATE zipay_tokens SET token = ?, expires_at = ? WHERE merchant_id = ?',
                    [$token, $expiresAt, $this->dbMerchantId]
                );
            } else {
                Database::execute(
                    'INSERT INTO zipay_tokens (merchant_id, token, expires_at) VALUES (?, ?, ?)',
                    [$this->dbMerchantId, $token, $expiresAt]
                );
            }
        }

        Logger::info('Zipay login berhasil', ['merchant_id' => $this->dbMerchantId]);
        return $token;
    }

    /**
     * Ambil token valid (dari cache DB atau login baru)
     */
    public function getToken(): string {
        if ($this->dbMerchantId > 0) {
            $cached = Database::fetchOne(
                'SELECT token, expires_at FROM zipay_tokens WHERE merchant_id = ? AND expires_at > NOW()',
                [$this->dbMerchantId]
            );

            if ($cached) {
                return $cached['token'];
            }
        }

        return $this->login();
    }

    // ============================================================
    // SIGNATURE
    // ============================================================

    /**
     * Generate signature HMAC-SHA256
     * Formula: HMAC-SHA256(merchant_id + external_id, merchant_key)
     */
    public function generateSignature(string $externalId): string {
        return hash_hmac(
            'sha256',
            $this->merchantId . $externalId,
            $this->merchantKey
        );
    }

    /**
     * Generate unique external ID
     */
    public function generateExternalId(string $prefix = 'TRX'): string {
        return $prefix . '-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -8));
    }

    // ============================================================
    // QRIS ENDPOINTS
    // ============================================================

    /**
     * Buat QRIS Dinamis (untuk terima pembayaran)
     * POST /payment/qr/create
     */
    public function createQRIS(int $amount, string $externalId): array {
        $token     = $this->getToken();
        $signature = $this->generateSignature($externalId);

        $response = $this->callAPI('/payment/qr/create', [
            'merchantId' => $this->merchantId,
            'externalId' => $externalId,
            'amount'     => $amount,
            'signature'  => $signature,
        ], $token);

        Logger::info('Zipay createQRIS', [
            'externalId' => $externalId,
            'amount'     => $amount,
            'success'    => isset($response['data']),
        ]);

        return $response;
    }

    /**
     * Cek status QRIS
     * POST /payment/qr/inquiry
     */
    public function inquiryStatus(string $uuid, string $externalId = ''): array {
        $token     = $this->getToken();

        if (empty($externalId)) {
            $externalId = $this->generateExternalId('INQ');
        }

        $signature = $this->generateSignature($externalId);

        $response = $this->callAPI('/payment/qr/inquiry', [
            'merchantId' => $this->merchantId,
            'uuid'       => $uuid,
            'externalId' => $externalId,
            'signature'  => $signature,
        ], $token);

        return $response;
    }

    /**
     * Ambil info merchant dari Zipay (termasuk saldo jika tersedia)
     * POST /merchant/getMerchant
     */
    public function getMerchantInfo(): array {
        $token    = $this->getToken();

        $response = $this->callAPI('/merchant/getMerchant', [
            'merchantId' => $this->merchantId,
        ], $token);

        return $response;
    }

    // ============================================================
    // HTTP HELPER
    // ============================================================

    /**
     * cURL request ke Zipay API
     */
    private function callAPI(
        string $endpoint,
        array $data,
        string $token = '',
        bool $requireToken = true
    ): array {
        $url = ZIPAY_BASE_URL . $endpoint;

        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
        ];

        if (!empty($token)) {
            $headers[] = 'Authorization: Bearer ' . $token;
        }

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($data),
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => ZIPAY_TIMEOUT,
            CURLOPT_SSL_VERIFYPEER => ZIPAY_VERIFY_SSL,
            CURLOPT_SSL_VERIFYHOST => ZIPAY_VERIFY_SSL ? 2 : 0,
        ]);

        $rawResponse = curl_exec($ch);
        $httpCode    = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError   = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            Logger::error('Zipay cURL error', ['endpoint' => $endpoint, 'error' => $curlError]);
            return ['success' => false, 'message' => 'Koneksi ke Zipay gagal: ' . $curlError];
        }

        $response = json_decode($rawResponse, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            Logger::error('Zipay invalid JSON response', ['endpoint' => $endpoint, 'raw' => $rawResponse]);
            return ['success' => false, 'message' => 'Response Zipay tidak valid'];
        }

        Logger::debug('Zipay API call', [
            'endpoint'  => $endpoint,
            'http_code' => $httpCode,
            'response'  => $response,
        ]);

        return $response;
    }
}
