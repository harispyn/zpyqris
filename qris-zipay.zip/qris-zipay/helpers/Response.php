<?php
// ============================================================
// JSON RESPONSE HELPER
// ============================================================

class Response {

    /**
     * Kirim response sukses
     */
    public static function success(
        mixed $data = null,
        string $message = 'Success',
        int $code = 200
    ): void {
        self::send($code, [
            'success' => true,
            'message' => $message,
            'data'    => $data,
        ]);
    }

    /**
     * Kirim response error
     */
    public static function error(
        string $message = 'Error',
        int $code = 400,
        array $errors = []
    ): void {
        $body = [
            'success' => false,
            'message' => $message,
        ];
        if (!empty($errors)) {
            $body['errors'] = $errors;
        }
        self::send($code, $body);
    }

    /**
     * 404 Not Found
     */
    public static function notFound(string $message = 'Resource not found'): void {
        self::error($message, 404);
    }

    /**
     * 401 Unauthorized
     */
    public static function unauthorized(string $message = 'Unauthorized'): void {
        self::error($message, 401);
    }

    /**
     * 403 Forbidden
     */
    public static function forbidden(string $message = 'Forbidden'): void {
        self::error($message, 403);
    }

    /**
     * 429 Too Many Requests
     */
    public static function tooManyRequests(string $message = 'Too many requests'): void {
        self::error($message, 429);
    }

    /**
     * 500 Server Error
     */
    public static function serverError(string $message = 'Internal server error'): void {
        self::error($message, 500);
    }

    /**
     * 422 Validation Error
     */
    public static function validationError(array $errors, string $message = 'Validation failed'): void {
        self::send(422, [
            'success' => false,
            'message' => $message,
            'errors'  => $errors,
        ]);
    }

    /**
     * Kirim JSON response dengan HTTP status code
     */
    public static function send(int $code, array $body): void {
        // Set CORS headers
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            http_response_code(204);
            exit;
        }

        header('Content-Type: application/json; charset=utf-8');
        header('X-App-Version: ' . APP_VERSION);

        http_response_code($code);

        // Tambah timestamp ke setiap response
        $body['timestamp'] = date('Y-m-d H:i:s');

        echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        exit;
    }
}
