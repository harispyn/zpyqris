<?php
// ============================================================
// QRIS EMV TLV PARSER
// Parse QRIS string sesuai standar EMV QRIS Indonesia
// ============================================================

class QRISParser {

    /**
     * Parse QRIS string format EMV TLV
     * @param  string $qrString  Raw QRIS string
     * @return array  Hasil parsing lengkap
     */
    public static function parse(string $qrString): array {
        $qrString = trim($qrString);

        if (empty($qrString)) {
            return self::errorResult('QR string kosong');
        }

        $tlv    = self::parseTLV($qrString);
        $result = [
            'raw'            => $qrString,
            'isValid'        => false,
            'isDynamic'      => false,
            'isStatic'       => false,
            'payloadFormat'  => null,
            'initiationMethod' => null,
            'merchantName'   => null,
            'merchantCity'   => null,
            'postalCode'     => null,
            'countryCode'    => null,
            'currency'       => null,
            'amount'         => null,
            'mid'            => null,
            'mpan'           => null,
            'criteria'       => null,
            'mcc'            => null,
            'referenceLabel' => null,
            'acquirer'       => null,
            'crc'            => null,
            'crcValid'       => false,
            'errors'         => [],
        ];

        // Tag 00: Payload Format Indicator
        if (isset($tlv['00'])) {
            $result['payloadFormat'] = $tlv['00'];
            if ($tlv['00'] !== '01') {
                $result['errors'][] = 'Payload format bukan 01';
            }
        }

        // Tag 01: Point of Initiation Method
        if (isset($tlv['01'])) {
            $result['initiationMethod'] = $tlv['01'];
            $result['isDynamic']  = ($tlv['01'] === '12');
            $result['isStatic']   = ($tlv['01'] === '11');
        }

        // Tag 26-45: Merchant Account Information (ID spesifik)
        for ($tag = 26; $tag <= 45; $tag++) {
            $tagStr = str_pad((string)$tag, 2, '0', STR_PAD_LEFT);
            if (isset($tlv[$tagStr])) {
                $subTlv = self::parseTLV($tlv[$tagStr]);

                // Sub-tag 00: GUID / Domain
                if (isset($subTlv['00'])) {
                    $result['acquirer'] = $subTlv['00'];
                }

                // Sub-tag 01: MID (Merchant ID) atau Merchant PAN
                if (isset($subTlv['01'])) {
                    $result['mpan'] = $subTlv['01'];
                }

                // Sub-tag 02: MID dari acquirer
                if (isset($subTlv['02'])) {
                    $result['mid'] = $subTlv['02'];
                }

                // Sub-tag 03: Criteria (UMI/UMK/UMB)
                if (isset($subTlv['03'])) {
                    $result['criteria'] = $subTlv['03'];
                }

                break; // gunakan yang pertama ditemukan
            }
        }

        // Tag 52: Merchant Category Code (MCC)
        if (isset($tlv['52'])) {
            $result['mcc'] = $tlv['52'];
        }

        // Tag 53: Transaction Currency
        if (isset($tlv['53'])) {
            $result['currency'] = $tlv['53'];
            // 360 = IDR (Indonesian Rupiah)
        }

        // Tag 54: Transaction Amount
        if (isset($tlv['54'])) {
            $result['amount'] = (float) $tlv['54'];
        }

        // Tag 58: Country Code
        if (isset($tlv['58'])) {
            $result['countryCode'] = $tlv['58'];
        }

        // Tag 59: Merchant Name
        if (isset($tlv['59'])) {
            $result['merchantName'] = $tlv['59'];
        }

        // Tag 60: Merchant City
        if (isset($tlv['60'])) {
            $result['merchantCity'] = $tlv['60'];
        }

        // Tag 61: Postal Code
        if (isset($tlv['61'])) {
            $result['postalCode'] = $tlv['61'];
        }

        // Tag 62: Additional Data Field Template
        if (isset($tlv['62'])) {
            $addData = self::parseTLV($tlv['62']);

            // Sub-tag 05: Reference Label
            if (isset($addData['05'])) {
                $result['referenceLabel'] = $addData['05'];
            }
        }

        // Tag 63: CRC (harus 4 karakter hex di akhir)
        if (isset($tlv['63'])) {
            $result['crc']      = $tlv['63'];
            $result['crcValid'] = self::validateCRC($qrString);
        }

        // Validasi minimal field
        if (empty($result['merchantName'])) {
            $result['errors'][] = 'Merchant name tidak ditemukan (tag 59)';
        }

        if (empty($result['mid']) && empty($result['mpan'])) {
            $result['errors'][] = 'Merchant ID tidak ditemukan';
        }

        // Cek QRIS valid
        $result['isValid'] = (
            empty($result['errors']) &&
            $result['crcValid'] &&
            $result['payloadFormat'] === '01'
        );

        return $result;
    }

    /**
     * Validasi CRC-16/CCITT QRIS
     * CRC dihitung dari seluruh string kecuali 4 karakter CRC di akhir
     * Tag 63 + length (0404) tetap diikutkan, hanya value CRC yang dikecualikan
     */
    public static function validateCRC(string $qrString): bool {
        // Cari posisi tag "6304" di akhir string
        $crcTagPos = strrpos($qrString, '6304');

        if ($crcTagPos === false) {
            return false;
        }

        // String yang dicek CRC = semua hingga setelah "6304" (inklusif)
        $toCheck     = substr($qrString, 0, $crcTagPos + 4);
        $expectedCRC = strtoupper(substr($qrString, $crcTagPos + 4, 4));
        $calculatedCRC = self::crc16($toCheck);

        return $calculatedCRC === $expectedCRC;
    }

    /**
     * Hitung CRC-16/CCITT (Polynomial: 0x1021, Init: 0xFFFF)
     */
    public static function crc16(string $str): string {
        $crc = 0xFFFF;

        for ($i = 0; $i < strlen($str); $i++) {
            $crc ^= (ord($str[$i]) << 8);

            for ($j = 0; $j < 8; $j++) {
                if ($crc & 0x8000) {
                    $crc = (($crc << 1) ^ 0x1021) & 0xFFFF;
                } else {
                    $crc = ($crc << 1) & 0xFFFF;
                }
            }
        }

        return strtoupper(str_pad(dechex($crc), 4, '0', STR_PAD_LEFT));
    }

    /**
     * Parse TLV (Tag-Length-Value) string
     * @param  string $data  TLV string
     * @return array  Associative array [tag => value]
     */
    public static function parseTLV(string $data): array {
        $result = [];
        $i      = 0;
        $len    = strlen($data);

        while ($i < $len) {
            // Tag: 2 karakter
            if ($i + 2 > $len) break;
            $tag = substr($data, $i, 2);
            $i  += 2;

            // Length: 2 karakter (desimal)
            if ($i + 2 > $len) break;
            $length = (int) substr($data, $i, 2);
            $i     += 2;

            // Value: sejumlah $length karakter
            if ($i + $length > $len) break;
            $value = substr($data, $i, $length);
            $i    += $length;

            $result[$tag] = $value;
        }

        return $result;
    }

    /**
     * Return error result
     */
    private static function errorResult(string $message): array {
        return [
            'raw'         => '',
            'isValid'     => false,
            'errors'      => [$message],
            'merchantName'=> null,
            'amount'      => null,
        ];
    }

    /**
     * Format amount ke Rupiah
     */
    public static function formatAmount(float $amount): string {
        return 'Rp ' . number_format($amount, 0, ',', '.');
    }

    /**
     * Generate QRIS string (untuk QR statis sederhana - keperluan testing)
     * @param string $mid          Merchant ID
     * @param string $mpan         Merchant PAN
     * @param string $merchantName Nama merchant
     * @param string $merchantCity Kota merchant
     * @param float  $amount       Nominal (0 = statis)
     * @return string              QRIS string dengan CRC valid
     */
    public static function generate(
        string $mid,
        string $mpan,
        string $merchantName,
        string $merchantCity,
        float $amount = 0
    ): string {
        // Payload Format Indicator
        $qr  = '000201';

        // Point of Initiation: 11=static, 12=dynamic
        $qr .= '0102' . ($amount > 0 ? '12' : '11');

        // Merchant Account Info (Tag 26) - ID.ZIPAY.WWW
        $guid    = 'ID.ZIPAY.WWW';
        $subTlv  = '0011' . $guid;
        $subTlv .= '01' . str_pad((string)strlen($mpan), 2, '0', STR_PAD_LEFT) . $mpan;
        $subTlv .= '02' . str_pad((string)strlen($mid), 2, '0', STR_PAD_LEFT) . $mid;
        $subTlv .= '0303UMI';
        $qr     .= '26' . str_pad((string)strlen($subTlv), 2, '0', STR_PAD_LEFT) . $subTlv;

        // Merchant Category Code
        $qr .= '52046532';

        // Transaction Currency: 360 = IDR
        $qr .= '5303360';

        // Transaction Amount (jika ada)
        if ($amount > 0) {
            $amountStr = (string)(int)$amount;
            $qr       .= '54' . str_pad((string)strlen($amountStr), 2, '0', STR_PAD_LEFT) . $amountStr;
        }

        // Country Code
        $qr .= '5802ID';

        // Merchant Name
        $qr .= '59' . str_pad((string)strlen($merchantName), 2, '0', STR_PAD_LEFT) . $merchantName;

        // Merchant City
        $qr .= '60' . str_pad((string)strlen($merchantCity), 2, '0', STR_PAD_LEFT) . $merchantCity;

        // CRC placeholder (akan dihitung)
        $qr .= '6304';

        // Hitung CRC dan tambahkan
        $qr .= self::crc16($qr);

        return $qr;
    }
}
