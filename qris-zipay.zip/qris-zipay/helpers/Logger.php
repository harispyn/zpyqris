<?php
// ============================================================
// LOGGER HELPER
// ============================================================

class Logger {

    /**
     * Log level info
     */
    public static function info(string $message, array $context = []): void {
        self::write('INFO', $message, $context);
    }

    /**
     * Log level error
     */
    public static function error(string $message, array $context = []): void {
        self::write('ERROR', $message, $context);
    }

    /**
     * Log level debug
     */
    public static function debug(string $message, array $context = []): void {
        if (LOG_LEVEL === 'debug') {
            self::write('DEBUG', $message, $context);
        }
    }

    /**
     * Log level warning
     */
    public static function warning(string $message, array $context = []): void {
        self::write('WARNING', $message, $context);
    }

    /**
     * Tulis ke file log
     */
    private static function write(string $level, string $message, array $context): void {
        if (!is_dir(LOG_PATH)) {
            mkdir(LOG_PATH, 0755, true);
        }

        $date      = date('Y-m-d');
        $time      = date('Y-m-d H:i:s');
        $logFile   = LOG_PATH . "app-{$date}.log";

        $contextStr = empty($context) ? '' : ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE);
        $line       = "[{$time}] [{$level}] {$message}{$contextStr}" . PHP_EOL;

        file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
    }
}
