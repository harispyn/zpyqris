<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QRIS Zipay - Dashboard</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  :root { --qris-red: #d32f2f; --qris-orange: #ff6f00; }
  body { background: #f5f5f5; font-family: 'Segoe UI', sans-serif; }
  .navbar { background: linear-gradient(135deg, var(--qris-red), var(--qris-orange)); }
  .navbar-brand, .nav-link { color: #fff !important; }
  .card { border: none; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
  .btn-qris { background: linear-gradient(135deg, var(--qris-red), var(--qris-orange)); color: #fff; border: none; }
  .btn-qris:hover { opacity: .9; color: #fff; }
  .badge-status-success  { background: #e8f5e9; color: #2e7d32; }
  .badge-status-pending  { background: #fff8e1; color: #f57f17; }
  .badge-status-failed   { background: #ffebee; color: #c62828; }
  #camera-container { position: relative; overflow: hidden; border-radius: 12px; background: #000; }
  #camera-video { width: 100%; max-height: 350px; object-fit: cover; }
  #scan-overlay { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
    width: 200px; height: 200px; border: 3px solid #fff; border-radius: 8px; pointer-events: none; }
  #scan-line { position: absolute; top: 0; left: 0; right: 0; height: 3px;
    background: var(--qris-red); animation: scanAnim 2s linear infinite; }
  @keyframes scanAnim { 0% { top:0; } 100% { top:calc(100% - 3px); } }
  .qr-img { border: 4px solid #fff; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,.15);
    animation: pulse 2s infinite; }
  @keyframes pulse { 0%,100%{box-shadow:0 4px 20px rgba(211,47,47,.3);} 50%{box-shadow:0 4px 40px rgba(211,47,47,.6);} }
  .saldo-card { background: linear-gradient(135deg, #1a237e, #283593); color:#fff; border-radius:16px; }
  .tab-pane { animation: fadeIn .3s ease; }
  @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">
      <i class="fas fa-qrcode me-2"></i>QRIS Zipay
    </a>
    <div class="ms-auto d-flex align-items-center">
      <span class="text-white me-3" id="merchant-name-nav">-</span>
      <button class="btn btn-outline-light btn-sm" onclick="logout()">
        <i class="fas fa-sign-out-alt"></i>
      </button>
    </div>
  </div>
</nav>

<div class="container">

  <!-- LOGIN FORM -->
  <div id="login-section" class="row justify-content-center">
    <div class="col-md-5">
      <div class="card p-4">
        <div class="text-center mb-4">
          <div style="font-size:3rem;color:var(--qris-red)"><i class="fas fa-qrcode"></i></div>
          <h4 class="fw-bold mt-2">QRIS Scan Pay</h4>
          <p class="text-muted">Login ke akun merchant Anda</p>
        </div>
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" id="login-email" class="form-control" placeholder="demo@example.com" value="demo@example.com">
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" id="login-password" class="form-control" value="password">
        </div>
        <button class="btn btn-qris w-100" onclick="doLogin()">
          <i class="fas fa-sign-in-alt me-2"></i>Login
        </button>
        <hr>
        <p class="text-center text-muted small">Belum punya akun? <a href="#" onclick="showRegister()">Daftar</a></p>
        <div id="login-alert"></div>
      </div>
    </div>
  </div>

  <!-- REGISTER FORM -->
  <div id="register-section" class="row justify-content-center d-none">
    <div class="col-md-6">
      <div class="card p-4">
        <h5 class="fw-bold mb-3"><i class="fas fa-user-plus me-2"></i>Daftar Merchant Baru</h5>
        <div class="row g-3">
          <div class="col-12">
            <input type="text" id="reg-name" class="form-control" placeholder="Nama Merchant *">
          </div>
          <div class="col-md-6">
            <input type="email" id="reg-email" class="form-control" placeholder="Email *">
          </div>
          <div class="col-md-6">
            <input type="password" id="reg-pass" class="form-control" placeholder="Password *">
          </div>
          <div class="col-12"><hr><small class="text-muted">Kredensial Zipay (opsional, bisa diisi nanti)</small></div>
          <div class="col-md-6">
            <input type="text" id="reg-uid" class="form-control" placeholder="Zipay User ID">
          </div>
          <div class="col-md-6">
            <input type="password" id="reg-upw" class="form-control" placeholder="Zipay Password">
          </div>
          <div class="col-md-6">
            <input type="text" id="reg-mid" class="form-control" placeholder="Zipay Merchant ID">
          </div>
          <div class="col-md-6">
            <input type="text" id="reg-mkey" class="form-control" placeholder="Zipay Merchant Key">
          </div>
          <div class="col-12">
            <button class="btn btn-qris w-100" onclick="doRegister()">Daftar</button>
            <button class="btn btn-outline-secondary w-100 mt-2" onclick="showLogin()">Sudah punya akun? Login</button>
          </div>
        </div>
        <div id="reg-alert" class="mt-3"></div>
      </div>
    </div>
  </div>

  <!-- DASHBOARD (setelah login) -->
  <div id="dashboard-section" class="d-none">

    <!-- Saldo Card -->
    <div class="saldo-card p-4 mb-4">
      <div class="row align-items-center">
        <div class="col">
          <div class="small opacity-75">Saldo Anda</div>
          <div class="fs-2 fw-bold" id="saldo-display">Memuat...</div>
        </div>
        <div class="col-auto">
          <button class="btn btn-outline-light btn-sm" onclick="loadBalance()">
            <i class="fas fa-sync-alt"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4" id="mainTabs">
      <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-scan">
          <i class="fas fa-camera me-1"></i> Scan & Bayar
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-receive">
          <i class="fas fa-qrcode me-1"></i> Terima Bayar
        </button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-history">
          <i class="fas fa-list me-1"></i> Riwayat
        </button>
      </li>
    </ul>

    <div class="tab-content">

      <!-- TAB 1: SCAN & BAYAR -->
      <div class="tab-pane fade show active" id="tab-scan">
        <div class="card p-4">
          <h5 class="fw-bold mb-3"><i class="fas fa-camera me-2 text-danger"></i>Scan QRIS & Bayar</h5>

          <div id="scan-steps">
            <!-- Step 1: Buka Kamera -->
            <div id="step-camera">
              <p class="text-muted">Arahkan kamera ke QR Code QRIS untuk scan otomatis.</p>
              <button class="btn btn-qris" id="btn-start-camera" onclick="startCamera()">
                <i class="fas fa-camera me-2"></i>Buka Kamera
              </button>

              <div id="camera-container" class="mt-3 d-none">
                <video id="camera-video" autoplay playsinline></video>
                <div id="scan-overlay"><div id="scan-line"></div></div>
                <canvas id="camera-canvas" class="d-none"></canvas>
              </div>
              <div id="scan-status" class="mt-2 text-muted small"></div>
              <button class="btn btn-outline-secondary btn-sm mt-2 d-none" id="btn-stop-camera" onclick="stopCamera()">
                <i class="fas fa-stop me-1"></i>Stop Kamera
              </button>
            </div>

            <!-- Step 2: Konfirmasi Bayar -->
            <div id="step-confirm" class="d-none">
              <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i><strong>QR Terdeteksi!</strong>
              </div>
              <div class="card bg-light p-3 mb-3">
                <div class="row">
                  <div class="col-6"><small class="text-muted">Merchant</small><div class="fw-bold" id="conf-merchant">-</div></div>
                  <div class="col-6"><small class="text-muted">Kota</small><div id="conf-city">-</div></div>
                  <div class="col-6 mt-2"><small class="text-muted">MID</small><div class="font-monospace small" id="conf-mid">-</div></div>
                  <div class="col-6 mt-2"><small class="text-muted">Tipe QR</small><div id="conf-qrtype">-</div></div>
                </div>
              </div>
              <div class="mb-3">
                <label class="form-label fw-bold">Nominal Pembayaran (Rp)</label>
                <input type="number" id="pay-amount" class="form-control form-control-lg"
                  placeholder="Masukkan nominal..." min="100" step="1000">
                <div class="form-text" id="pay-amount-note"></div>
              </div>
              <div class="mb-3">
                <label class="form-label">Keterangan (opsional)</label>
                <input type="text" id="pay-note" class="form-control" placeholder="mis: Bayar makan siang">
              </div>
              <div class="d-flex gap-2">
                <button class="btn btn-qris flex-fill" onclick="confirmPay()">
                  <i class="fas fa-paper-plane me-2"></i>Konfirmasi Bayar
                </button>
                <button class="btn btn-outline-secondary" onclick="resetScan()">
                  <i class="fas fa-redo"></i>
                </button>
              </div>
            </div>

            <!-- Step 3: Loading -->
            <div id="step-loading" class="text-center py-4 d-none">
              <div class="spinner-border text-danger mb-3"></div>
              <div>Memproses pembayaran...</div>
            </div>

            <!-- Step 4: Result -->
            <div id="step-result" class="d-none">
              <div id="result-content"></div>
              <button class="btn btn-qris mt-3 w-100" onclick="resetScan()">
                <i class="fas fa-camera me-2"></i>Scan QR Lain
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- TAB 2: TERIMA BAYAR -->
      <div class="tab-pane fade" id="tab-receive">
        <div class="card p-4">
          <h5 class="fw-bold mb-3"><i class="fas fa-qrcode me-2 text-danger"></i>Buat QR untuk Terima Bayar</h5>
          <div class="mb-3">
            <label class="form-label">Nominal (Rp) *</label>
            <input type="number" id="recv-amount" class="form-control form-control-lg" placeholder="50000" min="100">
          </div>
          <div class="mb-3">
            <label class="form-label">Keterangan</label>
            <input type="text" id="recv-note" class="form-control" placeholder="Keterangan pembayaran">
          </div>
          <button class="btn btn-qris w-100" onclick="createQRIS()">
            <i class="fas fa-qrcode me-2"></i>Generate QR
          </button>
          <div id="recv-result" class="mt-4 text-center d-none">
            <img id="recv-qr-img" src="" class="qr-img mb-3" width="240">
            <div class="fs-5 fw-bold" id="recv-amount-display"></div>
            <div class="text-muted small" id="recv-expire"></div>
            <div class="mt-2" id="recv-status-badge"></div>
            <div class="progress mt-3" style="height:6px">
              <div class="progress-bar bg-danger" id="recv-progress" style="width:100%"></div>
            </div>
            <button class="btn btn-outline-secondary btn-sm mt-3" onclick="stopPolling()">
              <i class="fas fa-stop me-1"></i>Stop Polling
            </button>
          </div>
        </div>
      </div>

      <!-- TAB 3: RIWAYAT -->
      <div class="tab-pane fade" id="tab-history">
        <div class="card p-3">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold mb-0">Riwayat Transaksi</h5>
            <button class="btn btn-outline-secondary btn-sm" onclick="loadTransactions()">
              <i class="fas fa-sync-alt"></i>
            </button>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-4">
              <select id="filter-type" class="form-select form-select-sm">
                <option value="">Semua Tipe</option>
                <option value="scan_pay">Scan Pay</option>
                <option value="receive">Terima</option>
                <option value="topup">Topup</option>
              </select>
            </div>
            <div class="col-4">
              <select id="filter-status" class="form-select form-select-sm">
                <option value="">Semua Status</option>
                <option value="success">Sukses</option>
                <option value="pending">Pending</option>
                <option value="failed">Gagal</option>
              </select>
            </div>
            <div class="col-4">
              <button class="btn btn-qris btn-sm w-100" onclick="loadTransactions()">Filter</button>
            </div>
          </div>
          <div id="trx-list">
            <div class="text-center text-muted py-4">
              <i class="fas fa-list fa-2x mb-2 d-block"></i>Klik refresh untuk memuat transaksi
            </div>
          </div>
        </div>
      </div>

    </div><!-- end tab-content -->
  </div><!-- end dashboard -->
</div><!-- end container -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>
<script>
// ============================================================
// KONFIGURASI
// ============================================================
const API_BASE  = window.location.origin + window.location.pathname.replace('/public/index.php','').replace('/index.php','');
const API_URL   = API_BASE; // index.php di root proyek

let token       = localStorage.getItem('qris_token') || '';
let merchantData = null;
let cameraStream = null;
let scanInterval = null;
let pollingInterval = null;
let scannedQR   = '';
let recvUUID    = '';
let recvTrxId   = '';

// ============================================================
// AUTH
// ============================================================
function authHeader() {
  return { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' };
}

async function apiCall(endpoint, method = 'GET', body = null) {
  const opts = { method, headers: authHeader() };
  if (body) opts.body = JSON.stringify(body);
  const res  = await fetch(API_URL + endpoint, opts);
  return res.json();
}

async function doLogin() {
  const email = document.getElementById('login-email').value;
  const pass  = document.getElementById('login-password').value;
  if (!email || !pass) return alert('Email dan password wajib diisi');

  const res = await fetch(API_URL + '/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: pass }),
  }).then(r => r.json());

  if (res.success) {
    token = res.data.token;
    localStorage.setItem('qris_token', token);
    merchantData = res.data;
    showDashboard();
  } else {
    document.getElementById('login-alert').innerHTML =
      `<div class="alert alert-danger mt-2">${res.message}</div>`;
  }
}

async function doRegister() {
  const data = {
    merchant_name:    document.getElementById('reg-name').value,
    email:            document.getElementById('reg-email').value,
    password:         document.getElementById('reg-pass').value,
    zipay_user_id:    document.getElementById('reg-uid').value,
    zipay_password:   document.getElementById('reg-upw').value,
    zipay_merchant_id:  document.getElementById('reg-mid').value,
    zipay_merchant_key: document.getElementById('reg-mkey').value,
  };

  const res = await fetch(API_URL + '/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  }).then(r => r.json());

  const el = document.getElementById('reg-alert');
  if (res.success) {
    el.innerHTML = `<div class="alert alert-success">Registrasi berhasil! API Key: <code>${res.data.api_key}</code><br>Silakan login.</div>`;
    setTimeout(showLogin, 3000);
  } else {
    el.innerHTML = `<div class="alert alert-danger">${res.message}</div>`;
  }
}

function logout() {
  localStorage.removeItem('qris_token');
  token = '';
  stopCamera();
  stopPolling();
  document.getElementById('dashboard-section').classList.add('d-none');
  document.getElementById('login-section').classList.remove('d-none');
}

function showRegister() {
  document.getElementById('login-section').classList.add('d-none');
  document.getElementById('register-section').classList.remove('d-none');
}

function showLogin() {
  document.getElementById('register-section').classList.add('d-none');
  document.getElementById('login-section').classList.remove('d-none');
}

function showDashboard() {
  document.getElementById('login-section').classList.add('d-none');
  document.getElementById('register-section').classList.add('d-none');
  document.getElementById('dashboard-section').classList.remove('d-none');
  if (merchantData) {
    document.getElementById('merchant-name-nav').textContent = merchantData.merchant_name || '';
  }
  loadBalance();
}

// ============================================================
// SALDO
// ============================================================
async function loadBalance() {
  const res = await apiCall('/api/balance');
  if (res.success) {
    document.getElementById('saldo-display').textContent = res.data.balance_formatted;
  }
}

// ============================================================
// SCAN & BAYAR
// ============================================================
async function startCamera() {
  try {
    const constraints = {
      video: {
        facingMode: { ideal: 'environment' }, // kamera belakang di HP
        width: { ideal: 1280 }, height: { ideal: 720 },
      }
    };
    cameraStream = await navigator.mediaDevices.getUserMedia(constraints);
    const video  = document.getElementById('camera-video');
    video.srcObject = cameraStream;

    document.getElementById('camera-container').classList.remove('d-none');
    document.getElementById('btn-start-camera').classList.add('d-none');
    document.getElementById('btn-stop-camera').classList.remove('d-none');
    document.getElementById('scan-status').textContent = '🔍 Mengarahkan kamera ke QR Code...';

    video.addEventListener('loadedmetadata', () => {
      scanInterval = setInterval(scanFrame, 200);
    });

  } catch (err) {
    alert('Gagal akses kamera: ' + err.message + '\n\nPastikan halaman menggunakan HTTPS atau localhost.');
  }
}

function scanFrame() {
  const video  = document.getElementById('camera-video');
  const canvas = document.getElementById('camera-canvas');
  if (!video.videoWidth) return;

  canvas.width  = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx     = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const code      = jsQR(imageData.data, imageData.width, imageData.height, {
    inversionAttempts: 'dontInvert',
  });

  if (code && code.data) {
    stopCamera();
    scannedQR = code.data;
    parseQRAndShowConfirm(code.data);
  }
}

function stopCamera() {
  if (cameraStream) {
    cameraStream.getTracks().forEach(t => t.stop());
    cameraStream = null;
  }
  if (scanInterval) {
    clearInterval(scanInterval);
    scanInterval = null;
  }
  document.getElementById('camera-container').classList.add('d-none');
  document.getElementById('btn-start-camera').classList.remove('d-none');
  document.getElementById('btn-stop-camera').classList.add('d-none');
}

async function parseQRAndShowConfirm(qrString) {
  document.getElementById('scan-status').textContent = '✅ QR terdeteksi! Memuat info...';

  const res = await apiCall('/api/qris/parse', 'POST', { qr_string: qrString });

  if (!res.success) {
    alert('Gagal parse QR: ' + res.message);
    resetScan();
    return;
  }

  const d = res.data;

  document.getElementById('conf-merchant').textContent = d.merchantName || 'Tidak diketahui';
  document.getElementById('conf-city').textContent     = d.merchantCity  || '-';
  document.getElementById('conf-mid').textContent      = d.mid            || d.mpan || '-';
  document.getElementById('conf-qrtype').textContent   = d.isDynamic ? '🔄 Dinamis' : '📌 Statis';

  const amountInput = document.getElementById('pay-amount');
  const amountNote  = document.getElementById('pay-amount-note');

  if (d.amount && d.amount > 0) {
    amountInput.value    = d.amount;
    amountInput.readOnly = true;
    amountNote.textContent = '⚠️ Nominal sudah tertera di QR: ' + (d.amountFormatted || d.amount);
  } else {
    amountInput.value    = '';
    amountInput.readOnly = false;
    amountNote.textContent = 'Masukkan nominal yang ingin dibayar';
  }

  document.getElementById('step-camera').classList.add('d-none');
  document.getElementById('step-confirm').classList.remove('d-none');
}

async function confirmPay() {
  const amount = parseFloat(document.getElementById('pay-amount').value);
  const note   = document.getElementById('pay-note').value;

  if (!amount || amount < 100) {
    alert('Nominal tidak valid (minimal Rp 100)');
    return;
  }

  document.getElementById('step-confirm').classList.add('d-none');
  document.getElementById('step-loading').classList.remove('d-none');

  const res = await apiCall('/api/qris/scan-pay', 'POST', {
    qr_string: scannedQR,
    amount:    amount,
    note:      note,
  });

  document.getElementById('step-loading').classList.add('d-none');
  document.getElementById('step-result').classList.remove('d-none');

  const el = document.getElementById('result-content');

  if (res.success) {
    const d = res.data;
    el.innerHTML = `
      <div class="alert alert-success text-center">
        <div style="font-size:3rem">✅</div>
        <h5 class="fw-bold mt-2">Pembayaran Berhasil!</h5>
        <div class="text-muted">ID: ${d.transaction_id}</div>
      </div>
      <table class="table table-sm">
        <tr><td>Merchant</td><td class="fw-bold">${d.payee?.merchant_name || '-'}</td></tr>
        <tr><td>Kota</td><td>${d.payee?.city || '-'}</td></tr>
        <tr><td>Nominal</td><td class="fw-bold text-danger">Rp ${d.amount?.toLocaleString('id-ID')}</td></tr>
        <tr><td>Saldo Sebelum</td><td>Rp ${d.balance_before?.toLocaleString('id-ID')}</td></tr>
        <tr><td>Saldo Sesudah</td><td class="fw-bold text-success">Rp ${d.balance_after?.toLocaleString('id-ID')}</td></tr>
        <tr><td>Status</td><td><span class="badge bg-success">${d.status}</span></td></tr>
        <tr><td>Waktu</td><td>${d.created_at}</td></tr>
      </table>`;
    loadBalance();
  } else {
    el.innerHTML = `
      <div class="alert alert-danger text-center">
        <div style="font-size:3rem">❌</div>
        <h5 class="fw-bold mt-2">Pembayaran Gagal</h5>
        <div>${res.message}</div>
      </div>`;
  }
}

function resetScan() {
  scannedQR = '';
  document.getElementById('step-camera').classList.remove('d-none');
  document.getElementById('step-confirm').classList.add('d-none');
  document.getElementById('step-loading').classList.add('d-none');
  document.getElementById('step-result').classList.add('d-none');
  document.getElementById('scan-status').textContent = '';
  document.getElementById('btn-start-camera').classList.remove('d-none');
}

// ============================================================
// TERIMA BAYAR (Create QRIS)
// ============================================================
async function createQRIS() {
  const amount = parseInt(document.getElementById('recv-amount').value);
  const note   = document.getElementById('recv-note').value;

  if (!amount || amount < 100) { alert('Isi nominal minimal Rp 100'); return; }

  const res = await apiCall('/api/qris/create', 'POST', { amount, note });

  if (!res.success) { alert('Gagal: ' + res.message); return; }

  const d = res.data;
  recvUUID  = d.zipay_uuid || '';
  recvTrxId = d.transaction_id;

  document.getElementById('recv-qr-img').src = d.qr_image_url;
  document.getElementById('recv-amount-display').textContent = 'Rp ' + amount.toLocaleString('id-ID');
  document.getElementById('recv-expire').textContent = 'Expired: ' + (d.expired_at || '-');
  document.getElementById('recv-status-badge').innerHTML = '<span class="badge bg-warning">Menunggu Pembayaran...</span>';
  document.getElementById('recv-result').classList.remove('d-none');

  startPolling(d.transaction_id, d.zipay_uuid);
}

function startPolling(trxId, uuid) {
  stopPolling();
  let tick = 100;
  pollingInterval = setInterval(async () => {
    tick -= 2;
    document.getElementById('recv-progress').style.width = tick + '%';
    if (tick <= 0) { stopPolling(); return; }

    const res = await apiCall('/api/qris/status', 'POST', { transaction_id: trxId });
    if (res.success) {
      const st = res.data.status;
      if (st === 'success') {
        document.getElementById('recv-status-badge').innerHTML =
          '<span class="badge bg-success fs-6">✅ LUNAS! Pembayaran Diterima</span>';
        stopPolling();
        loadBalance();
      } else if (st === 'expired' || st === 'failed') {
        document.getElementById('recv-status-badge').innerHTML =
          '<span class="badge bg-danger">❌ ' + st + '</span>';
        stopPolling();
      }
    }
  }, 5000);
}

function stopPolling() {
  if (pollingInterval) { clearInterval(pollingInterval); pollingInterval = null; }
}

// ============================================================
// RIWAYAT TRANSAKSI
// ============================================================
async function loadTransactions() {
  const type   = document.getElementById('filter-type').value;
  const status = document.getElementById('filter-status').value;
  let url = '/api/transactions?limit=20';
  if (type)   url += '&type='   + type;
  if (status) url += '&status=' + status;

  const res = await apiCall(url);
  const el  = document.getElementById('trx-list');

  if (!res.success) { el.innerHTML = '<div class="alert alert-danger">' + res.message + '</div>'; return; }

  if (!res.data.transactions.length) {
    el.innerHTML = '<div class="text-center text-muted py-4">Belum ada transaksi</div>';
    return;
  }

  const typeBadge   = { scan_pay:'danger', receive:'success', topup:'info', refund:'warning' };
  const statusBadge = { success:'success', pending:'warning', failed:'danger', expired:'secondary', processing:'info' };

  el.innerHTML = res.data.transactions.map(t => `
    <div class="border rounded p-3 mb-2">
      <div class="d-flex justify-content-between align-items-start">
        <div>
          <span class="badge bg-${typeBadge[t.type]||'secondary'} me-1">${t.type}</span>
          <span class="badge bg-${statusBadge[t.status]||'secondary'}">${t.status}</span>
          <div class="fw-bold mt-1">${t.payee_merchant_name || t.transaction_id}</div>
          <div class="text-muted small">${t.transaction_id} · ${t.created_at}</div>
        </div>
        <div class="text-end">
          <div class="fw-bold text-${t.type==='scan_pay'?'danger':'success'}">
            ${t.type==='scan_pay'?'-':'+'}Rp ${parseFloat(t.amount).toLocaleString('id-ID')}
          </div>
          <div class="text-muted small">${t.note || ''}</div>
        </div>
      </div>
    </div>`).join('');
}

// ============================================================
// AUTO INIT — Cek token tersimpan
// ============================================================
window.addEventListener('load', async () => {
  if (token) {
    const res = await apiCall('/api/auth/me');
    if (res.success) {
      merchantData = res.data;
      showDashboard();
    } else {
      localStorage.removeItem('qris_token');
      token = '';
    }
  }
});
</script>
</body>
</html>
