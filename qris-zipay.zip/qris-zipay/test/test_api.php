<?php
// ============================================================
// TEST API — Script untuk menguji semua endpoint
// Jalankan: php test/test_api.php
// ============================================================

require_once __DIR__ . '/../config/app.php';

define('TEST_API_URL', 'http://localhost/qris-zipay');
define('TEST_EMAIL',   'demo@example.com');
define('TEST_PASS',    'password');

$token      = '';
$merchantId = 0;
$passed     = 0;
$failed     = 0;

// QRIS sample valid untuk testing
define('SAMPLE_QRIS', '00020101021126580012ID.ZIPAY.WWW0118936008250081495104021ZPM1930311180020303UMI51440012ID.ZIPAY.WWW0118936008250081495104021ZPM193031118002520465325303360540550000580253036028802ID5912TOKO DEMO OK6015JAKARTA SELATAN6105121046300706QRST116304FE74');

// ─────────────────────────────────────────────────
function apiCall(string $endpoint, string $method = 'GET', array $body = [], string $token = ''): array {
    $url = TEST_API_URL . $endpoint;
    $headers = ['Content-Type: application/json'];
    if ($token) $headers[] = 'Authorization: Bearer ' . $token;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    if ($body) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));

    $resp  = curl_exec($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($resp, true) ?? ['raw' => $resp];
    $data['__http_code'] = $code;
    return $data;
}

function test(string $name, callable $fn): void {
    global $passed, $failed;
    echo "\n[TEST] {$name}\n";
    try {
        $result = $fn();
        if ($result === true || $result === null) {
            echo "  ✅ PASSED\n";
            $passed++;
        } else {
            echo "  ❌ FAILED: " . (is_string($result) ? $result : json_encode($result)) . "\n";
            $failed++;
        }
    } catch (Exception $e) {
        echo "  ❌ ERROR: " . $e->getMessage() . "\n";
        $failed++;
    }
}

echo "============================================================\n";
echo "  QRIS Zipay API — Test Suite\n";
echo "  URL: " . TEST_API_URL . "\n";
echo "============================================================\n";

// ─────────────────────────────────────────────────
// TEST 1: Health Check
// ─────────────────────────────────────────────────
test('Health Check', function() {
    $res = apiCall('/api/health');
    if (!$res['success']) return 'Health check gagal: ' . ($res['message'] ?? 'unknown');
    echo "     Status: " . $res['data']['status'] . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 2: Validate QRIS (tanpa auth)
// ─────────────────────────────────────────────────
test('Validate QRIS (valid)', function() {
    $res = apiCall('/api/qris/validate', 'POST', ['qr_string' => SAMPLE_QRIS]);
    echo "     isValid: "  . ($res['data']['isValid']  ? 'true' : 'false') . "\n";
    echo "     crcValid: " . ($res['data']['crcValid'] ? 'true' : 'false') . "\n";
    return true;
});

test('Validate QRIS (invalid string)', function() {
    $res = apiCall('/api/qris/validate', 'POST', ['qr_string' => 'INVALID_QR_STRING_123']);
    echo "     isValid: " . ($res['data']['isValid'] ? 'true' : 'false') . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 3: Login
// ─────────────────────────────────────────────────
test('Login', function() {
    global $token;
    $res = apiCall('/api/auth/login', 'POST', [
        'email'    => TEST_EMAIL,
        'password' => TEST_PASS,
    ]);
    if (!$res['success']) return 'Login gagal: ' . ($res['message'] ?? 'unknown');
    $token = $res['data']['token'];
    echo "     Token: " . substr($token, 0, 30) . "...\n";
    echo "     Saldo: Rp " . number_format($res['data']['balance'], 0, ',', '.') . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 4: Login gagal
// ─────────────────────────────────────────────────
test('Login (password salah)', function() {
    $res = apiCall('/api/auth/login', 'POST', [
        'email'    => TEST_EMAIL,
        'password' => 'salah123',
    ]);
    if ($res['success']) return 'Seharusnya login gagal';
    echo "     Message: " . $res['message'] . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 5: Me (profile)
// ─────────────────────────────────────────────────
test('GET /api/auth/me', function() {
    global $token;
    $res = apiCall('/api/auth/me', 'GET', [], $token);
    if (!$res['success']) return 'Gagal: ' . $res['message'];
    echo "     Merchant: " . $res['data']['merchant_name'] . "\n";
    echo "     Balance: Rp " . number_format($res['data']['balance'], 0, ',', '.') . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 6: Parse QRIS
// ─────────────────────────────────────────────────
test('Parse QRIS', function() {
    global $token;
    $res = apiCall('/api/qris/parse', 'POST', ['qr_string' => SAMPLE_QRIS], $token);
    if (!$res['success']) return 'Parse gagal: ' . $res['message'];
    echo "     Merchant: " . $res['data']['merchantName'] . "\n";
    echo "     City: "     . $res['data']['merchantCity'] . "\n";
    echo "     Amount: "   . ($res['data']['amount'] ?? 'tidak ada di QR') . "\n";
    echo "     isDynamic: ". ($res['data']['isDynamic'] ? 'yes' : 'no') . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 7: Cek Saldo
// ─────────────────────────────────────────────────
test('GET /api/balance', function() {
    global $token;
    $res = apiCall('/api/balance', 'GET', [], $token);
    if (!$res['success']) return 'Gagal: ' . $res['message'];
    echo "     Saldo: " . $res['data']['balance_formatted'] . "\n";
    echo "     Total TRX: " . $res['data']['statistics']['total_transactions'] . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 8: Scan Pay
// ─────────────────────────────────────────────────
test('POST /api/qris/scan-pay (Rp 10.000)', function() {
    global $token;
    $res = apiCall('/api/qris/scan-pay', 'POST', [
        'qr_string' => SAMPLE_QRIS,
        'amount'    => 10000,
        'note'      => 'Test scan pay',
    ], $token);
    echo "     HTTP: " . $res['__http_code'] . "\n";
    echo "     Success: " . ($res['success'] ? 'true' : 'false') . "\n";
    echo "     Message: " . $res['message'] . "\n";
    if ($res['success']) {
        echo "     TRX ID: "        . $res['data']['transaction_id'] . "\n";
        echo "     Saldo sesudah: Rp " . number_format($res['data']['balance_after'], 0, ',', '.') . "\n";
    }
    return true;
});

// ─────────────────────────────────────────────────
// TEST 9: Buat QRIS untuk terima bayar
// ─────────────────────────────────────────────────
test('POST /api/qris/create', function() {
    global $token;
    $res = apiCall('/api/qris/create', 'POST', [
        'amount' => 25000,
        'note'   => 'Test terima bayar',
    ], $token);
    echo "     Success: " . ($res['success'] ? 'true' : 'false') . "\n";
    if ($res['success']) {
        echo "     TRX ID: " . $res['data']['transaction_id'] . "\n";
        echo "     QR URL: " . substr($res['data']['qr_image_url'], 0, 60) . "...\n";
    } else {
        echo "     Message: " . $res['message'] . "\n";
    }
    return true;
});

// ─────────────────────────────────────────────────
// TEST 10: List Transaksi
// ─────────────────────────────────────────────────
test('GET /api/transactions', function() {
    global $token;
    $res = apiCall('/api/transactions?limit=5', 'GET', [], $token);
    if (!$res['success']) return 'Gagal: ' . $res['message'];
    echo "     Total: " . $res['data']['pagination']['total'] . " transaksi\n";
    echo "     Page:  " . $res['data']['pagination']['page'] . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 11: Scan Pay — saldo tidak cukup
// ─────────────────────────────────────────────────
test('Scan Pay — nominal terlalu besar (saldo tidak cukup)', function() {
    global $token;
    $res = apiCall('/api/qris/scan-pay', 'POST', [
        'qr_string' => SAMPLE_QRIS,
        'amount'    => 999999999,
    ], $token);
    if ($res['success']) return 'Seharusnya gagal karena saldo tidak cukup';
    echo "     Message: " . $res['message'] . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 12: Scan Pay — QR tidak valid
// ─────────────────────────────────────────────────
test('Scan Pay — QR tidak valid', function() {
    global $token;
    $res = apiCall('/api/qris/scan-pay', 'POST', [
        'qr_string' => 'QRIS_PALSU_TIDAK_VALID',
        'amount'    => 10000,
    ], $token);
    if ($res['success']) return 'Seharusnya gagal karena QR tidak valid';
    echo "     Message: " . $res['message'] . "\n";
    return true;
});

// ─────────────────────────────────────────────────
// TEST 13: Akses tanpa token
// ─────────────────────────────────────────────────
test('Akses tanpa token (401)', function() {
    $res = apiCall('/api/balance');
    if ($res['__http_code'] !== 401) return 'Seharusnya 401, dapat: ' . $res['__http_code'];
    echo "     HTTP 401 benar\n";
    return true;
});

// ─────────────────────────────────────────────────
// SUMMARY
// ─────────────────────────────────────────────────
echo "\n============================================================\n";
echo "  HASIL: {$passed} PASSED, {$failed} FAILED\n";
echo "============================================================\n";
