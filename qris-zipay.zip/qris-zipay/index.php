<?php
// ============================================================
// INDEX.PHP — Router Utama API Server
// ============================================================

require_once __DIR__ . '/config/app.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/zipay.php';

// Load helpers
require_once __DIR__ . '/helpers/Logger.php';
require_once __DIR__ . '/helpers/Response.php';
require_once __DIR__ . '/helpers/Database.php';
require_once __DIR__ . '/helpers/JWTHelper.php';
require_once __DIR__ . '/helpers/QRISParser.php';
require_once __DIR__ . '/helpers/ZipayService.php';

// Load middleware
require_once __DIR__ . '/api/middleware/auth.php';

// Load controllers
require_once __DIR__ . '/api/endpoints/auth.php';
require_once __DIR__ . '/api/endpoints/qris.php';
require_once __DIR__ . '/api/endpoints/balance.php';
require_once __DIR__ . '/api/endpoints/transactions.php';

// CORS
AuthMiddleware::cors();

// Routing
$method = $_SERVER['REQUEST_METHOD'];
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Hilangkan base path dari URI
$basePath = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
if ($basePath && str_starts_with($uri, $basePath)) {
    $uri = substr($uri, strlen($basePath));
}
$uri = '/' . trim($uri, '/');

// ──────────────────────────────────────────────────────────────
// ROUTES — Public (tidak butuh auth)
// ──────────────────────────────────────────────────────────────

// Health check
if ($method === 'GET' && $uri === '/api/health') {
    Response::success([
        'status'  => 'ok',
        'app'     => APP_NAME,
        'version' => APP_VERSION,
        'env'     => APP_ENV,
        'time'    => date('Y-m-d H:i:s'),
    ], 'API berjalan normal');
}

// Register merchant
if ($method === 'POST' && $uri === '/api/auth/register') {
    AuthController::register();
}

// Login
if ($method === 'POST' && $uri === '/api/auth/login') {
    AuthController::login();
}

// Validate QRIS (tanpa auth)
if ($method === 'POST' && $uri === '/api/qris/validate') {
    QRISController::validateQRIS();
}

// Webhook callback dari Zipay (tanpa auth JWT — dari server Zipay)
if ($method === 'POST' && ($uri === '/callback' || $uri === '/api/callback')) {
    TransactionController::callback();
}

// ──────────────────────────────────────────────────────────────
// ROUTES — Protected (butuh JWT auth)
// ──────────────────────────────────────────────────────────────

// Semua route di bawah ini wajib auth
AuthMiddleware::jwtAuth();

// Auth routes
if ($method === 'GET'  && $uri === '/api/auth/me')           AuthController::me();
if ($method === 'POST' && $uri === '/api/auth/update-zipay') AuthController::updateZipay();

// QRIS routes
if ($method === 'POST' && $uri === '/api/qris/scan-pay') {
    AuthMiddleware::rateLimiter('/api/qris/scan-pay');
    QRISController::scanPay();
}
if ($method === 'POST' && $uri === '/api/qris/create')  QRISController::createQRIS();
if ($method === 'POST' && $uri === '/api/qris/status')  QRISController::checkStatus();
if ($method === 'POST' && $uri === '/api/qris/parse')   QRISController::parseQRIS();

// Balance routes
if ($method === 'GET'  && $uri === '/api/balance')         BalanceController::check();
if ($method === 'GET'  && $uri === '/api/balance/logs')    BalanceController::logs();
if ($method === 'POST' && $uri === '/api/balance/topup')   BalanceController::topup();
if ($method === 'POST' && $uri === '/api/balance/sync')    BalanceController::syncFromZipay();

// Transaction routes
if ($method === 'GET' && $uri === '/api/transactions') {
    TransactionController::list();
}

// Transaction detail: GET /api/transactions/{id}
if ($method === 'GET' && preg_match('#^/api/transactions/([A-Z0-9\-]+)$#i', $uri, $m)) {
    TransactionController::detail($m[1]);
}

// ──────────────────────────────────────────────────────────────
// 404 — Route tidak ditemukan
// ──────────────────────────────────────────────────────────────
Response::notFound("Endpoint [{$method}] {$uri} tidak ditemukan");
