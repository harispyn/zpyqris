-- ============================================================
-- QRIS ZIPAY - DATABASE SCHEMA
-- ============================================================
-- Support: MySQL 5.7+ / MariaDB 10.3+
-- Untuk SQLite: hapus ENGINE, CHARSET, dan ON UPDATE CURRENT_TIMESTAMP
-- ============================================================

CREATE DATABASE IF NOT EXISTS `qris_zipay`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `qris_zipay`;

-- ============================================================
-- Tabel: merchants
-- Menyimpan data merchant yang terdaftar di sistem kita
-- ============================================================
CREATE TABLE IF NOT EXISTS `merchants` (
    `id`                INT         UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_name`     VARCHAR(100) NOT NULL,
    `email`             VARCHAR(100) NOT NULL UNIQUE,
    `password`          VARCHAR(255) NOT NULL,
    `phone`             VARCHAR(20)  DEFAULT NULL,
    -- Kredensial Zipay per merchant
    `zipay_user_id`     VARCHAR(100) DEFAULT NULL,
    `zipay_password`    VARCHAR(255) DEFAULT NULL,
    `zipay_merchant_id` VARCHAR(100) DEFAULT NULL,
    `zipay_merchant_key`VARCHAR(255) DEFAULT NULL,
    -- API Key untuk akses endpoint kita
    `api_key`           VARCHAR(64)  NOT NULL UNIQUE,
    -- Saldo internal
    `balance`           DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `status`            ENUM('active','inactive','suspended') NOT NULL DEFAULT 'active',
    `created_at`        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_email`   (`email`),
    INDEX `idx_api_key` (`api_key`),
    INDEX `idx_status`  (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabel: transactions
-- Menyimpan semua transaksi (scan pay, receive, topup)
-- ============================================================
CREATE TABLE IF NOT EXISTS `transactions` (
    `id`                INT         UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_id`    VARCHAR(50)  NOT NULL UNIQUE,
    `external_id`       VARCHAR(100) DEFAULT NULL,
    `zipay_uuid`        VARCHAR(100) DEFAULT NULL,
    `payer_merchant_id` INT         UNSIGNED DEFAULT NULL,
    -- Info penerima (dari parsing QRIS)
    `payee_merchant_name` VARCHAR(100) DEFAULT NULL,
    `payee_mid`         VARCHAR(100) DEFAULT NULL,
    `payee_mpan`        VARCHAR(100) DEFAULT NULL,
    `payee_city`        VARCHAR(100) DEFAULT NULL,
    -- Tipe & nominal
    `type`              ENUM('scan_pay','receive','topup','refund') NOT NULL,
    `amount`            DECIMAL(15,2) NOT NULL,
    `fee`               DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `total_amount`      DECIMAL(15,2) NOT NULL,
    -- Status
    `status`            ENUM('pending','processing','success','failed','expired','refunded') NOT NULL DEFAULT 'pending',
    -- Data tambahan
    `qr_string`         TEXT         DEFAULT NULL,
    `qr_image_url`      VARCHAR(500) DEFAULT NULL,
    `note`              VARCHAR(255) DEFAULT NULL,
    `response_data`     JSON         DEFAULT NULL,
    `paid_at`           TIMESTAMP    NULL DEFAULT NULL,
    `expired_at`        TIMESTAMP    NULL DEFAULT NULL,
    `created_at`        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_payer`       (`payer_merchant_id`),
    INDEX `idx_status`      (`status`),
    INDEX `idx_type`        (`type`),
    INDEX `idx_created`     (`created_at`),
    INDEX `idx_external`    (`external_id`),
    FOREIGN KEY (`payer_merchant_id`) REFERENCES `merchants`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabel: balance_logs
-- Log setiap perubahan saldo merchant
-- ============================================================
CREATE TABLE IF NOT EXISTS `balance_logs` (
    `id`              INT         UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_id`     INT         UNSIGNED NOT NULL,
    `transaction_id`  VARCHAR(50)  DEFAULT NULL,
    `type`            ENUM('debit','credit') NOT NULL,
    `amount`          DECIMAL(15,2) NOT NULL,
    `balance_before`  DECIMAL(15,2) NOT NULL,
    `balance_after`   DECIMAL(15,2) NOT NULL,
    `description`     VARCHAR(255) DEFAULT NULL,
    `created_at`      TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_merchant`    (`merchant_id`),
    INDEX `idx_transaction` (`transaction_id`),
    INDEX `idx_created`     (`created_at`),
    FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabel: zipay_tokens
-- Cache Bearer Token Zipay per merchant (hindari login berulang)
-- ============================================================
CREATE TABLE IF NOT EXISTS `zipay_tokens` (
    `id`          INT         UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `merchant_id` INT         UNSIGNED NOT NULL UNIQUE,
    `token`       TEXT        NOT NULL,
    `expires_at`  TIMESTAMP   NOT NULL,
    `created_at`  TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`merchant_id`) REFERENCES `merchants`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Tabel: rate_limits
-- Untuk tracking rate limit per API key
-- ============================================================
CREATE TABLE IF NOT EXISTS `rate_limits` (
    `id`          INT         UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `api_key`     VARCHAR(64)  NOT NULL,
    `endpoint`    VARCHAR(100) NOT NULL,
    `request_count` INT        NOT NULL DEFAULT 1,
    `window_start` TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_api_key`   (`api_key`),
    INDEX `idx_window`    (`window_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- INSERT: Contoh data merchant untuk testing
-- ============================================================
-- Password: 'password123' (bcrypt hash)
INSERT INTO `merchants` (
    `merchant_name`, `email`, `password`, `phone`,
    `zipay_user_id`, `zipay_password`,
    `zipay_merchant_id`, `zipay_merchant_key`,
    `api_key`, `balance`, `status`
) VALUES (
    'Toko Demo Saya',
    'demo@example.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password
    '081234567890',
    'YOUR_ZIPAY_USER_ID',
    'YOUR_ZIPAY_PASSWORD',
    'YOUR_MERCHANT_ID',
    'YOUR_MERCHANT_KEY',
    'demo-api-key-1234567890abcdef1234567890abcdef',
    1000000.00,
    'active'
);
