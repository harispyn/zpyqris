# 🔴 QRIS Zipay — Custom Scan Pay API Server

Script PHP REST API lengkap untuk QRIS Scan & Pay terintegrasi Zipay.

## 📁 Struktur File

```
qris-zipay/
├── index.php                    ← Router utama
├── .htaccess                    ← URL rewriting
├── config/
│   ├── app.php                  ← Konfigurasi JWT, rate limit, dll
│   ├── database.php             ← Konfigurasi DB (MySQL/SQLite)
│   └── zipay.php                ← Kredensial Zipay API
├── database/
│   └── schema.sql               ← SQL schema lengkap (5 tabel)
├── helpers/
│   ├── Database.php             ← PDO singleton helper
│   ├── Response.php             ← JSON response formatter
│   ├── Logger.php               ← File logger
│   ├── JWTHelper.php            ← JWT encode/decode (tanpa library)
│   ├── QRISParser.php           ← Parser QRIS EMV TLV + CRC16
│   └── ZipayService.php         ← Integrasi API Zipay
├── api/
│   ├── middleware/auth.php      ← JWT Auth, API Key, Rate Limiter
│   └── endpoints/
│       ├── auth.php             ← Login, Register, Me
│       ├── qris.php             ← ⭐ Scan Pay, Create, Status, Parse
│       ├── balance.php          ← Saldo, Log, Topup, Sync
│       └── transactions.php     ← List, Detail, Callback
├── public/
│   └── index.php               ← Dashboard UI (HTML+JS kamera)
├── test/
│   └── test_api.php            ← Test semua endpoint
└── logs/                       ← Log otomatis
```

## ⚡ Quick Start

### 1. Buat Database
```bash
mysql -u root -p < database/schema.sql
```

### 2. Edit Konfigurasi
```php
// config/database.php
define('DB_USER', 'root');
define('DB_PASS', 'password');
define('DB_NAME', 'qris_zipay');

// config/zipay.php
define('ZIPAY_USER_ID',     'your_user_id');
define('ZIPAY_PASSWORD',    'your_password');
define('ZIPAY_MERCHANT_ID', 'your_merchant_id');
define('ZIPAY_MERCHANT_KEY','your_merchant_key');

// config/app.php
define('JWT_SECRET', 'your-random-secret-key-32-chars');
define('APP_URL',    'https://yourdomain.com/qris-zipay');
```

### 3. Test API
```bash
php test/test_api.php
```

### 4. Akses Dashboard
Buka `https://yourdomain.com/qris-zipay/public/index.php`

## 🔗 Endpoint API

| Method | Endpoint | Auth | Keterangan |
|--------|----------|------|------------|
| GET | /api/health | ❌ | Status server |
| POST | /api/auth/register | ❌ | Daftar merchant |
| POST | /api/auth/login | ❌ | Login → JWT token |
| GET | /api/auth/me | ✅ | Info merchant |
| POST | /api/auth/update-zipay | ✅ | Update kredensial Zipay |
| **POST** | **/api/qris/scan-pay** | ✅ | **⭐ Scan & bayar QRIS** |
| POST | /api/qris/create | ✅ | Buat QR terima bayar |
| POST | /api/qris/status | ✅ | Cek status transaksi |
| POST | /api/qris/parse | ✅ | Parse QRIS string |
| POST | /api/qris/validate | ❌ | Validasi CRC QRIS |
| GET | /api/balance | ✅ | Cek saldo |
| GET | /api/balance/logs | ✅ | Log mutasi |
| POST | /api/balance/topup | ✅ | Topup saldo |
| POST | /api/balance/sync | ✅ | Sync dari Zipay |
| GET | /api/transactions | ✅ | Riwayat transaksi |
| GET | /api/transactions/{id} | ✅ | Detail transaksi |
| POST | /callback | ❌ | Webhook Zipay |

## 🔐 Autentikasi

Gunakan JWT token di header:
```
Authorization: Bearer {token}
```

## 📱 Contoh Request

### Login
```bash
curl -X POST https://yourdomain.com/qris-zipay/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@example.com","password":"password"}'
```

### Scan & Bayar
```bash
curl -X POST https://yourdomain.com/qris-zipay/api/qris/scan-pay \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d '{"qr_string":"00020101...","amount":50000,"note":"Bayar makan"}'
```

## ⚠️ Catatan Penting

- Wajib **HTTPS** untuk fitur kamera (getUserMedia)
- Endpoint `/api/qris/scan-pay` menggunakan saldo **internal DB** untuk deduct
- Untuk settlement ke Zipay, konfirmasi endpoint CPM ke **support@zipay.co.id**
- Demo credentials: `demo@example.com` / `password` (saldo Rp 1.000.000)

## 🛡️ Keamanan

- JWT Authentication (stateless, expire 24 jam)
- PDO Prepared Statements (anti SQL injection)
- DB Transaction ACID (COMMIT/ROLLBACK)
- Rate Limiting (60 req/menit)
- CRC-16 QRIS Validation
- CORS Headers

---
*Dibuat dengan ❤️ | Integrasi: docs.zipay.co.id*
