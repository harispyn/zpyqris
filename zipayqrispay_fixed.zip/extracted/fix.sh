#!/usr/bin/env bash
# ================================================================
#  fix_vps.sh – Zipay Russia (PHP Murni) – Fix & Deploy Script
#  Jalankan: sudo bash fix_vps.sh
#  Dari direktori mana saja. Script ini otomatis mendeteksi path.
# ================================================================

set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Konfigurasi (EDIT BAGIAN INI) ──────────────────────────────
APP_DIR="${APP_DIR:-/var/www/zipay}"
DB_NAME="${DB_NAME:-zipay_db}"
DB_USER="${DB_USER:-zipay_user}"
DB_PASS="${DB_PASS:-ZipayStr0ng2055!}"
DB_HOST="${DB_HOST:-127.0.0.1}"
APP_URL="${APP_URL:-http://$(hostname -I | awk '{print $1}')}"
# FIX BUG #1: API_BASE_URL default salah (apidev → api-dashboard)
API_BASE_URL="${API_BASE_URL:-https://api-dashboard.zipay.id}"
# FIX BUG #2: MID default salah (SIDINARSBP → SIDINARSBP2)
MID="${MID:-SIDINARSBP2}"
# FIX BUG #3: MERCHANT_TOKEN default tidak sinkron dengan config.php
MERCHANT_TOKEN="${MERCHANT_TOKEN:-SCLGGqdpRBcJiBlnRTFB41wuSI8CZ9tWEe1ubhoMYESrkv2du3qqmYmxF0oYh2aIdyxIVs/EIPjdDOhUvaWwcQ==}"
# FIX BUG #4: Tambahkan variabel Telegram (sebelumnya tidak ada)
TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-8303943197:AAGCFO1EuotDeoyXnRpSNsMiFSCddm6UlQ4}"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-590436982}"
PHP_VER="8.2"
# ───────────────────────────────────────────────────────────────

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; }
step()    { echo -e "\n${BLUE}━━━ $* ━━━${NC}"; }

# ── Root check ─────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    error "Script harus dijalankan sebagai root: sudo bash $0"
    exit 1
fi

step "1. Deteksi OS & install dependensi"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get install -y -q \
    software-properties-common curl wget ca-certificates gnupg lsb-release \
    unzip zip 2>&1 | tail -3

# Deteksi OS
OS_ID=$(lsb_release -si 2>/dev/null | tr '[:upper:]' '[:lower:]' || echo "ubuntu")
OS_VER=$(lsb_release -sr 2>/dev/null || echo "22.04")
info "OS: $OS_ID $OS_VER"

step "2. Install Apache2"
if ! command -v apache2 &>/dev/null; then
    apt-get install -y -q apache2 2>&1 | tail -3
    success "Apache2 terinstall"
else
    success "Apache2 sudah ada: $(apache2 -v 2>&1 | head -1)"
fi
systemctl enable apache2 --quiet

step "3. Install PHP $PHP_VER"
if ! php -v 2>/dev/null | grep -q "PHP $PHP_VER"; then
    # Tambah repo Ondrej
    if [[ "$OS_ID" == "ubuntu" ]]; then
        add-apt-repository -y ppa:ondrej/php 2>&1 | tail -2
    else
        curl -sSL https://packages.sury.org/php/README.txt | bash 2>&1 | tail -2
    fi
    apt-get update -q
    apt-get install -y -q \
        php${PHP_VER} libapache2-mod-php${PHP_VER} \
        php${PHP_VER}-cli php${PHP_VER}-common \
        php${PHP_VER}-mysql php${PHP_VER}-curl \
        php${PHP_VER}-mbstring php${PHP_VER}-xml \
        php${PHP_VER}-json php${PHP_VER}-zip \
        php${PHP_VER}-gd php${PHP_VER}-intl 2>&1 | tail -5
    success "PHP ${PHP_VER} terinstall"
else
    success "PHP sudah ada: $(php -v 2>&1 | head -1)"
fi

# Set default PHP Apache
a2dismod php7.* php8.0 php8.1 php8.3 php8.4 2>/dev/null || true
a2enmod php${PHP_VER} 2>/dev/null && success "mod_php${PHP_VER} aktif" || warn "a2enmod php${PHP_VER} gagal"

step "4. Enable Apache modules"
a2enmod rewrite headers deflate expires 2>/dev/null
success "Module Apache aktif: rewrite headers deflate expires"

step "5. Install MySQL"
if ! command -v mysql &>/dev/null; then
    info "Install MySQL Server..."
    # Coba MySQL 8.0 dari repo default
    apt-get install -y -q mysql-server 2>&1 | tail -3 || \
    apt-get install -y -q mariadb-server 2>&1 | tail -3
    success "MySQL/MariaDB terinstall"
else
    success "MySQL sudah ada: $(mysql --version 2>&1 | head -1)"
fi
# FIX BUG #5: enable mysql/mariadb satu per satu, jangan digabung
systemctl enable mysql 2>/dev/null || systemctl enable mariadb 2>/dev/null || true
systemctl start  mysql 2>/dev/null || systemctl start  mariadb 2>/dev/null || true

step "6. Setup database"
MYSQL_CMD="mysql"
# FIX BUG #6: tambahkan opsi --defaults-file untuk auth_socket Ubuntu baru
if $MYSQL_CMD -e "SELECT 1;" 2>/dev/null; then
    info "MySQL root tanpa password – OK"
elif $MYSQL_CMD -uroot -e "SELECT 1;" 2>/dev/null; then
    MYSQL_CMD="mysql -uroot"
    info "MySQL root dengan -uroot – OK"
elif mysql --defaults-file=/etc/mysql/debian.cnf -e "SELECT 1;" 2>/dev/null; then
    MYSQL_CMD="mysql --defaults-file=/etc/mysql/debian.cnf"
    info "MySQL via debian.cnf maintenance credentials – OK"
else
    warn "Tidak bisa koneksi MySQL tanpa password – lanjut coba anyway"
fi

# Buat DB & user
$MYSQL_CMD 2>/dev/null <<SQLEOF
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'${DB_HOST}' IDENTIFIED BY '${DB_PASS}';
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'${DB_HOST}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQLEOF

if [[ $? -eq 0 ]]; then
    success "Database '${DB_NAME}' & user '${DB_USER}' siap"
else
    warn "Gagal buat DB/user – cek manual: mysql -uroot"
fi

# Import schema jika ada
SQL_FILE="${SCRIPT_DIR}/zipay_database.sql"
if [[ -f "$SQL_FILE" ]]; then
    $MYSQL_CMD "${DB_NAME}" < "$SQL_FILE" 2>/dev/null && success "Schema diimport dari zipay_database.sql" || warn "Import schema gagal (mungkin sudah ada)"
fi

step "7. Deploy file ke $APP_DIR"
mkdir -p "$APP_DIR"

# FIX BUG #7: Tambah -mindepth 1 agar SCRIPT_DIR sendiri tidak ikut disalin
# FIX BUG #8: Tambah -type f agar hanya file (bukan direktori) yang disalin di sini
info "Menyalin file dari $SCRIPT_DIR ke $APP_DIR ..."
find "$SCRIPT_DIR" -mindepth 1 -maxdepth 1 \
    -type f \
    ! -name "*.sh" \
    ! -name "*.sql" \
    -print0 | xargs -0 -I{} cp -r {} "$APP_DIR/" 2>/dev/null || true

# Salin subfolder penting
for d in includes fonts images javascript styles app; do
    if [[ -d "$SCRIPT_DIR/$d" ]]; then
        cp -r "$SCRIPT_DIR/$d" "$APP_DIR/"
        success "  Disalin: $d/"
    fi
done

# Copy hidden file
[[ -f "$SCRIPT_DIR/.htaccess" ]] && cp "$SCRIPT_DIR/.htaccess" "$APP_DIR/.htaccess" && success "  .htaccess disalin"

# Verifikasi file utama
MISSING=()
for f in index.php login.php register.php activation.php verify-otp.php home.php logout.php config.php; do
    [[ -f "$APP_DIR/$f" ]] || MISSING+=("$f")
done
if [[ ${#MISSING[@]} -gt 0 ]]; then
    warn "File berikut tidak ada di $APP_DIR: ${MISSING[*]}"
else
    success "Semua file PHP utama ada di $APP_DIR"
fi

step "8. Generate config.php"
cat > "${APP_DIR}/config.php" <<PHPEOF
<?php
// ================================================================
//  config.php – auto-generated oleh fix_vps.sh
//  Jangan edit langsung – jalankan ulang script dengan variabel baru
// ================================================================

// Database
define('DB_HOST',     '${DB_HOST}');
define('DB_PORT',     '3306');
define('DB_NAME',     '${DB_NAME}');
define('DB_USER',     '${DB_USER}');
define('DB_PASS',     '${DB_PASS}');

// Multipocket API
define('API_BASE_URL',       '${API_BASE_URL}');
define('API_MID',            '${MID}');
define('API_MERCHANT_TOKEN', '${MERCHANT_TOKEN}');

// Aplikasi
define('APP_NAME',  'Zipay Russia');
define('APP_URL',   '${APP_URL}');
define('APP_DEBUG', false);  // FIX BUG #9: default false untuk keamanan production

// Session
define('SESSION_LIFETIME', 7200);

date_default_timezone_set('Asia/Jakarta');

error_reporting(0);
ini_set('display_errors', '0');

// ── Telegram Bot ─────────────────────────────────────────────
// FIX BUG #4: Telegram config ditambahkan agar tele.sh/notifikasi berfungsi
define('TELEGRAM_BOT_TOKEN', getenv('TELEGRAM_BOT_TOKEN') ?: '${TELEGRAM_BOT_TOKEN}');
define('TELEGRAM_CHAT_ID',   getenv('TELEGRAM_CHAT_ID')   ?: '${TELEGRAM_CHAT_ID}');
define('TELEGRAM_ENABLED',   !empty(TELEGRAM_BOT_TOKEN) && !empty(TELEGRAM_CHAT_ID));
PHPEOF
success "config.php digenerate"

step "9. Set permissions"
chown -R www-data:www-data "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} \;
find "$APP_DIR" -type f -exec chmod 644 {} \;
chmod 640 "${APP_DIR}/config.php"
# Blokir akses ke file sensitif via filesystem
chmod 640 "${APP_DIR}/zipay_database.sql" 2>/dev/null || true
success "Permissions diset"

step "10. Konfigurasi Apache VirtualHost"
VHOST_FILE="/etc/apache2/sites-available/zipay.conf"
cat > "$VHOST_FILE" <<APACHEEOF
<VirtualHost *:80>
    ServerName ${APP_URL##http://}
    ServerAlias www.${APP_URL##http://}
    DocumentRoot ${APP_DIR}

    <Directory ${APP_DIR}>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Blokir akses ke file sensitif
    <FilesMatch "(config\.php|\.sql|\.sh|\.env)$">
        Require all denied
    </FilesMatch>

    # FIX BUG #10: <FilesMatch "^includes/"> tidak berfungsi karena FilesMatch
    # hanya mencocokkan nama file, bukan path. Ganti dengan <Directory>.
    <Directory ${APP_DIR}/includes>
        Require all denied
    </Directory>

    # PHP settings
    <IfModule mod_php${PHP_VER/./}.c>
        php_flag display_errors Off
        php_flag log_errors On
        php_value error_log ${APP_DIR}/php_errors.log
    </IfModule>

    ErrorLog  /var/log/apache2/zipay_error.log
    CustomLog /var/log/apache2/zipay_access.log combined
</VirtualHost>
APACHEEOF

a2dissite 000-default.conf 2>/dev/null || true
a2ensite zipay.conf 2>/dev/null
success "VirtualHost zipay.conf aktif"

step "11. Test konfigurasi Apache"
# FIX BUG #11: Tangkap exit code configtest dengan benar agar $? tidak hilang
CONFIGTEST_OUTPUT=$(apache2ctl configtest 2>&1)
CONFIGTEST_RC=$?
echo "$CONFIGTEST_OUTPUT"
if [[ $CONFIGTEST_RC -eq 0 ]]; then
    success "Apache config OK"
else
    error "Ada error di Apache config – periksa log di atas"
fi

step "12. Restart Apache"
systemctl restart apache2
if systemctl is-active --quiet apache2; then
    success "Apache berjalan"
else
    error "Apache gagal restart!"
    journalctl -u apache2 --no-pager -n 20
fi

step "13. Verifikasi asset"
for dir in fonts images javascript styles; do
    if [[ -d "$APP_DIR/$dir" ]]; then
        COUNT=$(find "$APP_DIR/$dir" -type f | wc -l)
        success "  $dir/ → $COUNT file"
    else
        warn "  $dir/ TIDAK ADA di $APP_DIR"
    fi
done

step "14. Smoke test HTTP (route check)"
sleep 1
BASE="${APP_URL}"
ROUTES=("/" "/login" "/register" "/activation" "/verify-otp" "/reset-password")
ALL_OK=true
for route in "${ROUTES[@]}"; do
    CODE=$(curl -sk -o /dev/null -w "%{http_code}" -L --max-redirs 3 "${BASE}${route}" 2>/dev/null || echo "ERR")
    if [[ "$CODE" == "200" || "$CODE" == "302" ]]; then
        success "  ${route} → HTTP $CODE"
    else
        warn "  ${route} → HTTP $CODE ← perlu investigasi"
        ALL_OK=false
    fi
done

if $ALL_OK; then
    success "Semua route OK!"
else
    warn "Beberapa route belum 200/302. Cek log:"
    echo "  tail -50 /var/log/apache2/zipay_error.log"
    echo "  tail -50 /var/log/apache2/zipay_access.log"
fi

step "━━━ Selesai ━━━"
echo ""
echo -e "${GREEN}App URL   :${NC} ${APP_URL}"
echo -e "${GREEN}Dir       :${NC} ${APP_DIR}"
echo -e "${GREEN}DB Name   :${NC} ${DB_NAME}"
echo -e "${GREEN}DB User   :${NC} ${DB_USER}"
echo -e "${GREEN}DB Pass   :${NC} ${DB_PASS}"
echo ""
echo -e "Apache log: /var/log/apache2/zipay_error.log"
echo -e "PHP log   : ${APP_DIR}/php_errors.log"
echo ""
echo -e "${YELLOW}Edit kredensial API di: ${APP_DIR}/config.php${NC}"
echo ""
