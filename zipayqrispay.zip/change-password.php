<?php
// ============================================================
//  change-password.php – Ubah Password/PIN
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_login();

$errors      = [];
$success     = session_flash_get('success');
$phoneNumber = session_get('phoneNumber', '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { $errors[] = 'Token keamanan tidak valid.'; }
    else {
        $newPin        = $_POST['newPin']        ?? '';
        $confirmNewPin = $_POST['confirmNewPin'] ?? '';
        $otp           = trim($_POST['otp']      ?? '');

        if (strlen($newPin) < 6)       $errors[] = 'PIN baru minimal 6 karakter.';
        if ($newPin !== $confirmNewPin) $errors[] = 'Konfirmasi PIN tidak cocok.';
        if ($otp === '')               $errors[] = 'Kode OTP wajib diisi.';

        if (empty($errors)) {
            // Step 1: request OTP jika belum
            $reqResult = api_post('/api/Merchant/ChangePin', base_payload([
                'phoneNo' => $phoneNumber,
            ]));

            // Step 2: verify OTP + set new pin
            $result = api_post('/api/Merchant/VerifyChangePin', base_payload([
                'phoneNo'       => $phoneNumber,
                'newPin'        => $newPin,
                'confirmNewPin' => $confirmNewPin,
                'otp'           => (int)$otp,
            ]));

            if ($result['ok']) {
                session_flash('success', 'PIN berhasil diubah!');
                header('Location: /settings');
                exit;
            } else {
                $errors[] = 'Gagal mengubah PIN: ' . $result['message'];
            }
        }
    }
}

$page_title = 'Ubah Password';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-4">
    <div class="tf-container">
        <form class="tf-form" action="/change-password" method="POST">
            <?= csrf_field() ?>
            <h1>Ubah Password / PIN</h1>
            <p class="fw_4">Nomor HP: <strong><?= htmlspecialchars($phoneNumber) ?></strong></p>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="alert alert-danger"><ul>
                    <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul></div>
            <?php endif; ?>

            <div class="group-input">
                <label>PIN Baru (min. 6 digit)</label>
                <input type="password" name="newPin" minlength="6" placeholder="PIN baru" required>
            </div>
            <div class="group-input">
                <label>Konfirmasi PIN Baru</label>
                <input type="password" name="confirmNewPin" placeholder="Ulangi PIN baru" required>
            </div>
            <div class="group-input">
                <label>Kode OTP (dikirim ke nomor HP Anda)</label>
                <input type="text" name="otp" inputmode="numeric" maxlength="6"
                       placeholder="Masukkan OTP" required>
            </div>

            <button type="submit" class="tf-btn accent large">Simpan PIN Baru</button>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
