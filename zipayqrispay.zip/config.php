<?php
// ================================================================
//  config.php – auto-generated oleh fix_vps.sh
//  Jangan edit langsung – jalankan ulang script dengan variabel baru
// ================================================================

// Database
define('DB_HOST',     '127.0.0.1');
define('DB_PORT',     '3306');
define('DB_NAME',     'zipay_db');
define('DB_USER',     'zipay_user');
define('DB_PASS',     'ZipayStr0ng2055!');

// Multipocket API
define('API_BASE_URL',       'https://api-dashboard.zipay.id');
define('API_MID',            'SIDINARSBP2');
define('API_MERCHANT_TOKEN', 'SCLGGqdpRBcJiBlnRTFB41wuSI8CZ9tWEe1ubhoMYESrkv2du3qqmYmxF0oYh2aIdyxIVs/EIPjdDOhUvaWwcQ==');

// Aplikasi
define('APP_NAME',  'Zipay Russia');
define('APP_URL',   'https://zipayku.xyz');
define('APP_DEBUG', true);  // SET false setelah debug selesai

// Session
define('SESSION_LIFETIME', 7200);

date_default_timezone_set('Asia/Jakarta');

error_reporting(0);
ini_set('display_errors', '0');

// ── Telegram Bot ─────────────────────────────────────────────
define('TELEGRAM_BOT_TOKEN', getenv('TELEGRAM_BOT_TOKEN') ?: '8303943197:AAGCFO1EuotDeoyXnRpSNsMiFSCddm6UlQ4');
define('TELEGRAM_CHAT_ID',   getenv('TELEGRAM_CHAT_ID')   ?: '590436982');
define('TELEGRAM_ENABLED',   !empty(TELEGRAM_BOT_TOKEN) && !empty(TELEGRAM_CHAT_ID));
