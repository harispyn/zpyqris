#!/bin/bash
# ================================================================
#  debug_register.sh – Test API Register langsung via curl
#  Jalankan di VPS: bash debug_register.sh
#  Edit variabel di bawah ini sebelum jalankan
# ================================================================

API_BASE_URL="https://apidev.zipay.id"
MID="SIDINARSBP"
MERCHANT_TOKEN="7SERR3d79Q3qzghi4YCA04qQwKn/y3gbe2ZKBmwk/1s="

# ── Data test register (ganti sesuai data real) ──
FIRSTNAME="Test"
LASTNAME="User"
EMAIL="testuser$(date +%s)@example.com"   # auto-unique email
PHONENO="08$(shuf -i 100000000-999999999 -n 1)"  # random phone
PIN="123456"

echo "━━━ DEBUG: Test API Register ━━━"
echo "URL     : ${API_BASE_URL}/api/Multipocket/Register"
echo "MID     : $MID"
echo "Token   : $MERCHANT_TOKEN"
echo "Phone   : $PHONENO"
echo "Email   : $EMAIL"
echo ""

PAYLOAD=$(cat <<JSON
{
    "mid": "$MID",
    "merchantToken": "$MERCHANT_TOKEN",
    "firstName": "$FIRSTNAME",
    "lastName": "$LASTNAME",
    "email": "$EMAIL",
    "phoneNo": "$PHONENO",
    "pin": "$PIN"
}
JSON
)

echo "━━━ Payload JSON yang dikirim: ━━━"
echo "$PAYLOAD"
echo ""

echo "━━━ Response API: ━━━"
curl -sk \
    -X POST \
    -H "Content-Type: application/json" \
    -H "Accept: application/json" \
    -d "$PAYLOAD" \
    "${API_BASE_URL}/api/Multipocket/Register" \
    -w "\n\nHTTP Status: %{http_code}\n"

echo ""
echo "━━━ Selesai ━━━"
echo ""
echo "Jika HTTP 400: periksa format field di atas vs dokumentasi API"
echo "Jika HTTP 401: MID atau MERCHANT_TOKEN salah"
echo "Jika HTTP 200: API OK, masalah ada di PHP/Apache"
