<?php
// ============================================================
//  register.php – Halaman & proses registrasi
//  v2.1 – PIN numeric, better error, debug raw response
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_guest();

$errors   = [];
$apiDebug = '';   // raw API response (tampil jika APP_DEBUG = true)
$success  = session_flash_get('success');
$old      = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!csrf_verify()) {
        $errors[] = 'Token keamanan tidak valid. Muat ulang halaman.';
    } else {
        // ── Ambil & bersihkan input ──────────────────────────────
        $firstName = trim($_POST['firstName'] ?? '');
        $lastName  = trim($_POST['lastName']  ?? '');
        $email     = trim($_POST['email']     ?? '');
        // Hapus semua non-digit dari phoneNo, lalu prepend sesuai kebutuhan
        $phoneRaw  = trim($_POST['phoneNo']   ?? '');
        $phoneNo   = preg_replace('/[^0-9+]/', '', $phoneRaw);  // biarkan + untuk kode negara
        $pin       = trim($_POST['pin'] ?? '');

        $old = [
            'firstName' => $firstName,
            'lastName'  => $lastName,
            'email'     => $email,
            'phoneNo'   => $phoneRaw,
        ];

        // ── Validasi ────────────────────────────────────────────
        if ($firstName === '') $errors[] = 'First name wajib diisi.';
        if ($lastName  === '') $errors[] = 'Last name wajib diisi.';
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL))
            $errors[] = 'Email tidak valid.';
        if ($phoneNo === '') $errors[] = 'Nomor telepon wajib diisi.';
        if (!ctype_digit($pin))  $errors[] = 'PIN harus berupa angka saja (0-9).';
        elseif (strlen($pin) < 6) $errors[] = 'PIN minimal 6 digit.';

        if (empty($errors)) {

            // ── Kirim ke API ─────────────────────────────────────
            $result = api_post('/api/Multipocket/Register', base_payload([
                'firstName' => $firstName,
                'lastName'  => $lastName,
                'email'     => $email,
                'phoneNo'   => $phoneNo,
                'pin'       => $pin,           // string numerik
            ]));

            // Simpan raw response untuk debug
            $apiDebug = $result['raw'] ?? '';

            if ($result['ok']) {
                session_flash('success', 'Registrasi berhasil! Silakan aktivasi akun Anda.');
                header('Location: /activation?phoneNo=' . urlencode($phoneNo));
                exit;
            } else {
                // Tampilkan pesan lengkap dari API
                $errMsg = $result['message'] ?? 'Terjadi kesalahan tidak diketahui.';

                // Jika masih "Bad Request" generik, tambahkan raw body di debug
                if (stripos($errMsg, 'Bad Request') !== false && $apiDebug) {
                    $errMsg .= ' | Detail: ' . htmlspecialchars(substr($apiDebug, 0, 300));
                }

                $errors[] = 'Registrasi gagal: ' . $errMsg;
            }
        }
    }
}

$page_title = 'Daftar Akun';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="mt-3 register-section">
    <div class="tf-container">
        <form class="tf-form" action="/register" method="POST" autocomplete="off">
            <?= csrf_field() ?>
            <h1>Daftar Akun</h1>

            <?php if ($success): ?>
                <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <?php endif; ?>

            <?php if ($errors): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach ($errors as $e): ?>
                            <li><?= htmlspecialchars($e) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if (APP_DEBUG && $apiDebug): ?>
                <div style="background:#f5f5f5;border:1px solid #ccc;padding:10px;font-size:11px;
                            border-radius:6px;margin-bottom:10px;word-break:break-all;">
                    <strong>DEBUG – Raw API Response:</strong><br>
                    <code><?= htmlspecialchars($apiDebug) ?></code>
                </div>
            <?php endif; ?>

            <div class="group-input">
                <label>First Name</label>
                <input type="text" name="firstName" placeholder="Masukkan nama depan"
                       value="<?= htmlspecialchars($old['firstName'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>Last Name</label>
                <input type="text" name="lastName" placeholder="Masukkan nama belakang"
                       value="<?= htmlspecialchars($old['lastName'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>Email</label>
                <input type="email" name="email" placeholder="Masukkan email"
                       value="<?= htmlspecialchars($old['email'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>Nomor Telepon</label>
                <small class="text-muted">Format: 08xxxxxxxxxx atau +628xxxxxxxxxx</small>
                <input type="tel" name="phoneNo" placeholder="Contoh: 08123456789"
                       value="<?= htmlspecialchars($old['phoneNo'] ?? '') ?>" required>
            </div>
            <div class="group-input">
                <label>PIN (6 digit angka)</label>
                <small class="text-muted">Hanya angka, min. 6 digit</small>
                <div class="group-input-icon">
                    <input type="password" name="pin" id="pin"
                           placeholder="Masukkan PIN angka" minlength="6"
                           inputmode="numeric" pattern="[0-9]*" required>
                    <span class="right-icon btn-show-pass">
                        <i class="icon-eye-off" id="toggle-pin"></i>
                    </span>
                </div>
            </div>

            <button type="submit" class="tf-btn accent large">Buat Akun</button>

            <p class="mt-3 text-center">
                Sudah punya akun? <a href="/login">Login di sini</a>
            </p>
        </form>
    </div>
</div>

<script>
document.getElementById('toggle-pin')?.addEventListener('click', function(){
    var inp = document.getElementById('pin');
    if (inp.type === 'password') {
        inp.type = 'text';
        this.classList.replace('icon-eye-off','icon-eye');
    } else {
        inp.type = 'password';
        this.classList.replace('icon-eye','icon-eye-off');
    }
});
// Izinkan hanya angka di field PIN
document.getElementById('pin')?.addEventListener('input', function(){
    this.value = this.value.replace(/[^0-9]/g, '');
});
</script>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
