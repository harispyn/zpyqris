#!/usr/bin/env bash
# ================================================================
#  setup_telegram.sh – Konfigurasi Telegram Bot untuk Zipay Russia
#  Jalankan: sudo TELEGRAM_BOT_TOKEN="TOKEN" TELEGRAM_CHAT_ID="CHATID" bash setup_telegram.sh
# ================================================================

APP_DIR="${APP_DIR:-/var/www/zipay}"
BOT_TOKEN="${8303943197:AAGCFO1EuotDeoyXnRpSNsMiFSCddm6UlQ4:-}"
CHAT_ID="${590436982:-}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; }

[[ $EUID -ne 0 ]] && { error "Jalankan sebagai root: sudo bash $0"; exit 1; }

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🤖 Setup Telegram Bot – Zipay Russia"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Input token jika belum ada ─────────────────────────────────
if [[ -z "$BOT_TOKEN" ]]; then
    echo ""
    echo "  Cara dapat Bot Token:"
    echo "  1. Buka Telegram, cari @BotFather"
    echo "  2. Ketik /newbot → masukkan nama & username"
    echo "  3. BotFather akan kasih token seperti: 1234567890:AAF..."
    echo ""
    read -p "  Masukkan TELEGRAM_BOT_TOKEN: " BOT_TOKEN
fi

if [[ -z "$CHAT_ID" ]]; then
    echo ""
    echo "  Cara dapat Chat ID:"
    echo "  1. Cari @userinfobot di Telegram"
    echo "  2. Ketik /start → bot akan tampilkan ID Anda"
    echo "  3. Untuk group: tambah bot ke group, ketik /start@nama_bot"
    echo ""
    read -p "  Masukkan TELEGRAM_CHAT_ID: " CHAT_ID
fi

[[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]] && { error "Token atau Chat ID kosong!"; exit 1; }

# ── Test koneksi Telegram ──────────────────────────────────────
info "Test koneksi Telegram..."
DOMAIN="zipayku.xyz"
HOST=$(hostname)
IP=$(hostname -I | awk '{print $1}')
TS=$(date '+%Y-%m-%d %H:%M:%S')

TEST_MSG="✅ *Zipay Russia – Telegram Connected*

Domain : \`${DOMAIN}\`
Host   : \`${HOST} (${IP})\`
Time   : \`${TS}\`

🔔 Notifikasi aktif untuk:
• Register gagal/sukses
• Login gagal
• API error
• PHP fatal error
• Apache down
• HTTP 5xx errors
• Log Apache error"

RESPONSE=$(curl -s -X POST \
    "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" \
    -H "Content-Type: application/json" \
    -d "{\"chat_id\":\"${CHAT_ID}\",\"text\":\"${TEST_MSG}\",\"parse_mode\":\"Markdown\"}" \
    --max-time 15 2>/dev/null)

if echo "$RESPONSE" | grep -q '"ok":true'; then
    success "Telegram terhubung! Cek chat Anda."
else
    error "Gagal kirim pesan Telegram!"
    echo "  Response: $RESPONSE"
    echo ""
    warn "Kemungkinan penyebab:"
    warn "  1. BOT_TOKEN salah"
    warn "  2. CHAT_ID salah"
    warn "  3. Bot belum di-start (kirim /start ke bot Anda)"
    exit 1
fi

# ── Update config.php dengan credentials ──────────────────────
info "Update config.php dengan Telegram credentials..."
if [[ -f "${APP_DIR}/config.php" ]]; then
    # Tambah Telegram config jika belum ada
    if ! grep -q "TELEGRAM_BOT_TOKEN" "${APP_DIR}/config.php"; then
        cat >> "${APP_DIR}/config.php" << TGCONF

// ── Telegram Bot ─────────────────────────────────────────────
define('TELEGRAM_BOT_TOKEN', getenv('TELEGRAM_BOT_TOKEN') ?: '${BOT_TOKEN}');
define('TELEGRAM_CHAT_ID',   getenv('TELEGRAM_CHAT_ID')   ?: '${CHAT_ID}');
define('TELEGRAM_ENABLED',   !empty(TELEGRAM_BOT_TOKEN) && !empty(TELEGRAM_CHAT_ID));
TGCONF
        success "Telegram config ditambahkan ke config.php"
    else
        # Update existing
        sed -i "s|define('TELEGRAM_BOT_TOKEN'.*|define('TELEGRAM_BOT_TOKEN', '${BOT_TOKEN}');|" "${APP_DIR}/config.php"
        sed -i "s|define('TELEGRAM_CHAT_ID'.*|define('TELEGRAM_CHAT_ID',   '${CHAT_ID}');|" "${APP_DIR}/config.php"
        success "Telegram credentials di-update di config.php"
    fi
else
    warn "config.php tidak ditemukan di ${APP_DIR}"
    warn "Jalankan fix_only.sh terlebih dahulu"
fi

# ── Copy log_monitor.sh ke app dir ────────────────────────────
info "Install log_monitor.sh..."
MONITOR_SCRIPT="${APP_DIR}/log_monitor.sh"
if [[ -f "$(dirname "${BASH_SOURCE[0]}")/log_monitor.sh" ]]; then
    cp "$(dirname "${BASH_SOURCE[0]}")/log_monitor.sh" "$MONITOR_SCRIPT"
elif [[ -f "${APP_DIR}/log_monitor.sh" ]]; then
    : # sudah ada
else
    warn "log_monitor.sh tidak ditemukan, skip"
fi

if [[ -f "$MONITOR_SCRIPT" ]]; then
    chmod +x "$MONITOR_SCRIPT"
    success "log_monitor.sh siap di ${MONITOR_SCRIPT}"
fi

# ── Install cron job ──────────────────────────────────────────
info "Install cron job (setiap 5 menit)..."
CRON_CMD="*/5 * * * * TELEGRAM_BOT_TOKEN='${BOT_TOKEN}' TELEGRAM_CHAT_ID='${CHAT_ID}' APP_DIR='${APP_DIR}' bash ${MONITOR_SCRIPT} >> /var/log/zipay_monitor.log 2>&1"

# Cek apakah cron sudah ada
if crontab -l 2>/dev/null | grep -q "log_monitor.sh"; then
    warn "Cron log_monitor sudah ada, menimpa..."
    (crontab -l 2>/dev/null | grep -v "log_monitor.sh"; echo "$CRON_CMD") | crontab -
else
    (crontab -l 2>/dev/null; echo "$CRON_CMD") | crontab -
fi
success "Cron dipasang: setiap 5 menit"

# ── Jalankan pertama kali ──────────────────────────────────────
info "Jalankan monitor pertama kali..."
TELEGRAM_BOT_TOKEN="$BOT_TOKEN" TELEGRAM_CHAT_ID="$CHAT_ID" APP_DIR="$APP_DIR" bash "$MONITOR_SCRIPT" 2>/dev/null
success "Monitor pertama dijalankan"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
success "  🤖 Telegram monitoring AKTIF!"
echo ""
echo "  Bot Token : ${BOT_TOKEN:0:20}..."
echo "  Chat ID   : ${CHAT_ID}"
echo "  Monitor   : ${MONITOR_SCRIPT}"
echo "  Cron      : setiap 5 menit"
echo "  Log       : /var/log/zipay_monitor.log"
echo ""
echo "  Cek log monitor : tail -f /var/log/zipay_monitor.log"
echo "  Lihat cron       : crontab -l"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
