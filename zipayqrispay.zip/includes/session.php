<?php
// ============================================================
//  includes/session.php – Manajemen session PHP native
// ============================================================
require_once __DIR__ . '/../config.php';

function session_init(): void {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'secure'   => false,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function session_set(string $key, $value): void {
    session_init();
    $_SESSION[$key] = $value;
}

function session_get(string $key, $default = null) {
    session_init();
    return $_SESSION[$key] ?? $default;
}

function session_has(string $key): bool {
    session_init();
    return isset($_SESSION[$key]);
}

function session_forget(string $key): void {
    session_init();
    unset($_SESSION[$key]);
}

function session_flash(string $key, $value): void {
    session_init();
    $_SESSION['_flash'][$key] = $value;
}

function session_flash_get(string $key, $default = null) {
    session_init();
    $value = $_SESSION['_flash'][$key] ?? $default;
    unset($_SESSION['_flash'][$key]);
    return $value;
}

function session_destroy_all(): void {
    session_init();
    $_SESSION = [];
    session_destroy();
}

function is_logged_in(): bool {
    session_init();
    return !empty($_SESSION['logged_in']) && !empty($_SESSION['token']);
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: /login');
        exit;
    }
}

function require_guest(): void {
    if (is_logged_in()) {
        header('Location: /home');
        exit;
    }
}

function csrf_token(): string {
    session_init();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify(): bool {
    $token = $_POST['_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return hash_equals(csrf_token(), $token);
}

function csrf_field(): string {
    return '<input type="hidden" name="_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

// Jalankan session otomatis saat file ini di-include
session_init();
