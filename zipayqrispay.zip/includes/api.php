<?php
// ============================================================
//  includes/api.php – Helper curl untuk Multipocket API
//  v2.1 – Better error extraction + raw body logging
// ============================================================
require_once __DIR__ . '/../config.php';

/**
 * Kirim POST request ke Multipocket API
 *
 * @param  string $endpoint   Misal: '/api/Multipocket/Register'
 * @param  array  $payload    Data JSON yang dikirim
 * @param  string $token      Bearer token (opsional)
 * @return array  ['ok'=>bool, 'status'=>int, 'data'=>array|null, 'message'=>string, 'raw'=>string]
 */
function api_post(string $endpoint, array $payload, string $token = ''): array {
    $url     = rtrim(API_BASE_URL, '/') . $endpoint;
    $json    = json_encode($payload, JSON_UNESCAPED_UNICODE);
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
        'Content-Length: ' . strlen($json),
    ];
    if ($token) {
        $headers[] = 'Authorization: Bearer ' . $token;
    }

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $json,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_FOLLOWLOCATION => false,
    ]);

    $body       = curl_exec($ch);
    $httpStatus = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError  = curl_error($ch);
    curl_close($ch);

    // Log setiap request untuk debugging
    error_log("[API] {$endpoint} payload=" . $json);
    error_log("[API] {$endpoint} HTTP={$httpStatus} body=" . substr((string)$body, 0, 500));

    // cURL error (network / timeout)
    if ($body === false || $curlError) {
        error_log("[API] cURL error on {$endpoint}: {$curlError}");
        return [
            'ok'      => false,
            'status'  => 0,
            'data'    => null,
            'raw'     => '',
            'message' => 'Tidak dapat terhubung ke server API. Periksa koneksi VPS. Error: ' . $curlError,
        ];
    }

    // Parse JSON body
    $decoded = json_decode($body, true);

    // HTTP 2xx = sukses
    if ($httpStatus >= 200 && $httpStatus < 300) {
        return [
            'ok'      => true,
            'status'  => $httpStatus,
            'data'    => $decoded,
            'raw'     => $body,
            'message' => api_extract_message($decoded) ?: 'Sukses',
        ];
    }

    // HTTP error — ekstrak pesan selengkap mungkin
    $message = api_extract_message($decoded);

    // Jika tidak ada message dari JSON, coba raw body
    if (!$message && $body) {
        $message = substr(strip_tags($body), 0, 300);
    }
    if (!$message) {
        $message = api_status_message($httpStatus);
    }

    error_log("[API] ERROR {$httpStatus} on {$endpoint}: {$message}");
    return [
        'ok'      => false,
        'status'  => $httpStatus,
        'data'    => $decoded,
        'raw'     => $body,
        'message' => $message,
    ];
}

/**
 * Ekstrak pesan error dari berbagai format response API
 */
function api_extract_message($decoded): string {
    if (!is_array($decoded)) return '';

    // Coba semua kemungkinan field pesan
    $candidates = [
        $decoded['message']       ?? null,
        $decoded['Message']       ?? null,
        $decoded['error']         ?? null,
        $decoded['Error']         ?? null,
        $decoded['title']         ?? null,
        $decoded['Title']         ?? null,
        $decoded['detail']        ?? null,
        $decoded['Detail']        ?? null,
        $decoded['description']   ?? null,
        $decoded['Description']   ?? null,
    ];

    foreach ($candidates as $c) {
        if (!empty($c) && is_string($c)) return $c;
    }

    // Cek field errors (array of strings)
    $errArrays = ['errors', 'Errors', 'validationErrors', 'ValidationErrors'];
    foreach ($errArrays as $key) {
        if (!empty($decoded[$key])) {
            $arr = $decoded[$key];
            if (is_string($arr)) return $arr;
            if (is_array($arr)) {
                $parts = [];
                foreach ($arr as $k => $v) {
                    if (is_string($v)) $parts[] = $v;
                    elseif (is_array($v)) $parts[] = implode(', ', $v);
                    else $parts[] = "$k: " . json_encode($v);
                }
                if ($parts) return implode(' | ', $parts);
            }
        }
    }

    return '';
}

function api_status_message(int $code): string {
    return match($code) {
        400 => 'Bad Request – Data tidak valid atau field tidak sesuai format API.',
        401 => 'Unauthorized – MID/merchantToken salah.',
        403 => 'Forbidden – Akses ditolak oleh server API.',
        404 => 'Not Found – Endpoint API tidak ditemukan.',
        409 => 'Conflict – Data sudah terdaftar (nomor/email sudah ada).',
        422 => 'Unprocessable – Data tidak dapat diproses.',
        429 => 'Too Many Requests – Terlalu banyak percobaan, tunggu sebentar.',
        500 => 'Internal Server Error – Kesalahan internal server API.',
        502 => 'Bad Gateway – API Gateway error.',
        503 => 'Service Unavailable – Server API tidak tersedia.',
        504 => 'Gateway Timeout – Server API timeout.',
        default => "HTTP {$code} – Server API merespon dengan kode tidak dikenal.",
    };
}

/** Buat payload dasar dengan mid + merchantToken */
function base_payload(array $extra = []): array {
    return array_merge([
        'mid'           => API_MID,
        'merchantToken' => API_MERCHANT_TOKEN,
    ], $extra);
}
