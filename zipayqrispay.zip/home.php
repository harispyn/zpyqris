<?php
// ============================================================
//  home.php – Dashboard utama (require login)
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/api.php';

require_login();

$apiResponse = session_get('api_response', []);
$firstName   = session_get('firstName', 'User');
$lastName    = session_get('lastName',  '');
$phoneNumber = session_get('phoneNumber', '');
$token       = session_get('token', '');
$balance     = 0;
$balanceError = '';

// Ambil saldo
$result = api_post('/api/Multipocket/Balance', base_payload([
    'phoneNo'   => $phoneNumber,
    'userToken' => $token,
]));

if ($result['ok']) {
    $balance = $result['data']['result']['zipayPocket'] ?? 0;
} else {
    $balanceError = $result['message'];
}

$userName   = trim($firstName . ' ' . $lastName);
$page_title = 'Beranda';
$show_back  = false;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="app-header">
    <div class="tf-container">
        <div class="tf-topbar d-flex justify-content-between align-items-center">
            <a class="user-info d-flex justify-content-between align-items-center" href="/profile">
                <img src="/images/user/user1.jpg" alt="user">
                <div class="content">
                    <h4 class="white_color"><?= htmlspecialchars($userName) ?></h4>
                    <p class="white_color fw_4">Selamat datang di Zipay!</p>
                </div>
            </a>
            <div class="d-flex align-items-center gap-4">
                <a href="/logout" class="white_color" title="Logout"
                   onclick="return confirm('Yakin ingin logout?')">
                    <i class="icon-logout" style="font-size:22px;color:#fff;"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Balance Card -->
<div class="card-secton">
    <div class="tf-container">
        <div class="tf-balance-box">
            <div class="balance">
                <div class="row">
                    <div class="col-6 br-right">
                        <div class="inner-left">
                            <p>Saldo Anda:</p>
                            <?php if ($balanceError): ?>
                                <small style="color:#ffcc80;"><?= htmlspecialchars($balanceError) ?></small>
                            <?php else: ?>
                                <h3>Rp <?= number_format((int)$balance, 0, ',', '.') ?></h3>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="inner-right">
                            <p>Nomor HP</p>
                            <h4 style="font-size:13px;"><?= htmlspecialchars($phoneNumber) ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Quick Actions -->
            <div class="wallet-footer">
                <ul class="d-flex justify-content-between align-items-center">
                    <li class="wallet-card-item">
                        <a class="fw_6" href="/qr-code">
                            <ul class="icon icon-my-qr">
                                <li class="path1"></li><li class="path2"></li>
                                <li class="path3"></li><li class="path4"></li>
                            </ul>
                            My QR
                        </a>
                    </li>
                    <li class="wallet-card-item">
                        <a class="fw_6" href="/scan-qr">
                            <ul class="icon icon-group-transfers">
                                <li class="path1"></li><li class="path2"></li><li class="path3"></li>
                            </ul>
                            Scan QR
                        </a>
                    </li>
                    <li class="wallet-card-item">
                        <a class="fw_6" href="/profile">
                            <ul class="icon icon-group-credit-card">
                                <li class="path1"></li><li class="path2"></li><li class="path3"></li>
                            </ul>
                            Profil
                        </a>
                    </li>
                    <li class="wallet-card-item">
                        <a class="fw_6" href="/settings">
                            <ul class="icon icon-topup">
                                <li class="path1"></li><li class="path2"></li>
                                <li class="path3"></li><li class="path4"></li>
                            </ul>
                            Pengaturan
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Info -->
<div class="mt-5">
    <div class="tf-container">
        <div class="tf-title d-flex justify-content-between">
            <h3 class="fw_6">Layanan</h3>
        </div>
        <ul class="box-service mt-3">
            <li>
                <a href="/profile">
                    <div class="icon-box bg_color_1">
                        <i class="icon-user" style="font-size:24px;color:#283EB4;"></i>
                    </div>
                    Profil
                </a>
            </li>
            <li>
                <a href="/qr-code">
                    <div class="icon-box bg_color_2">
                        <i class="icon-my-qr" style="font-size:24px;color:#1E90FF;"></i>
                    </div>
                    QR Code
                </a>
            </li>
            <li>
                <a href="/settings">
                    <div class="icon-box bg_color_3">
                        <i class="icon-settings" style="font-size:24px;color:#DA9B00;"></i>
                    </div>
                    Pengaturan
                </a>
            </li>
            <li>
                <a href="/logout" onclick="return confirm('Yakin ingin logout?')">
                    <div class="icon-box" style="background:#ffe0e0;">
                        <i class="icon-logout" style="font-size:24px;color:#D32F2F;"></i>
                    </div>
                    Logout
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- Bottom nav -->
<div class="bottom-navigation-bar">
    <div class="tf-container">
        <ul class="d-flex justify-content-around">
            <li><a href="/home" class="active"><i class="icon-home1"></i><span>Home</span></a></li>
            <li><a href="/profile"><i class="icon-user"></i><span>Profil</span></a></li>
            <li><a href="/qr-code"><i class="icon-my-qr"></i><span>QR</span></a></li>
            <li><a href="/settings"><i class="icon-setting1"></i><span>Setting</span></a></li>
        </ul>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
