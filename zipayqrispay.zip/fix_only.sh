#!/usr/bin/env bash
# ================================================================
#  fix_only.sh – Zipay Russia: Fix Apache config + permissions saja
#  Jalankan dari: /var/www/zipay/
#  sudo bash fix_only.sh
# ================================================================

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PHP_VER="8.2"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; }

[[ $EUID -ne 0 ]] && { error "Jalankan sebagai root: sudo bash $0"; exit 1; }

echo "━━━ Fix Apache + permissions untuk $APP_DIR ━━━"

# 1. Enable modules
a2enmod rewrite headers deflate expires 2>/dev/null
info "Module Apache: rewrite headers deflate expires"

# 2. Deteksi PHP version yang terinstall
if php -v 2>/dev/null | grep -qE "PHP 8\.[0-9]"; then
    PHP_VER=$(php -v | grep -oP "PHP \K[0-9]+\.[0-9]+")
fi
info "PHP version: $PHP_VER"

# Enable mod_php
a2enmod php${PHP_VER} 2>/dev/null || a2enmod php8.2 2>/dev/null || true

# 3. Tulis VirtualHost
VHOST="/etc/apache2/sites-available/zipay.conf"
cat > "$VHOST" <<EOF
<VirtualHost *:80>
    DocumentRoot ${APP_DIR}

    <Directory ${APP_DIR}>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    <FilesMatch "(config\.php|\.sql|\.sh|\.env)$">
        Require all denied
    </FilesMatch>

    ErrorLog  /var/log/apache2/zipay_error.log
    CustomLog /var/log/apache2/zipay_access.log combined
</VirtualHost>
EOF
a2dissite 000-default.conf 2>/dev/null || true
a2ensite zipay.conf 2>/dev/null
success "VirtualHost zipay.conf aktif, DocumentRoot = $APP_DIR"

# 4. Permissions
chown -R www-data:www-data "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 755 {} \;
find "$APP_DIR" -type f -exec chmod 644 {} \;
[[ -f "$APP_DIR/config.php" ]] && chmod 640 "$APP_DIR/config.php"
success "Permissions diset (www-data:www-data)"

# 5. Restart Apache
apache2ctl configtest 2>&1
systemctl restart apache2
systemctl is-active --quiet apache2 && success "Apache restart OK" || error "Apache gagal restart!"

# 6. Cek asset
for dir in fonts images javascript styles; do
    if [[ -d "$APP_DIR/$dir" ]]; then
        success "  $dir/ ADA ($(find "$APP_DIR/$dir" -type f | wc -l) files)"
    else
        warn "  $dir/ TIDAK ADA – upload asset!"
    fi
done

# 7. Smoke test
sleep 1
IP=$(hostname -I | awk '{print $1}')
for r in / /login /register /activation; do
    CODE=$(curl -sk -o /dev/null -w "%{http_code}" "http://$IP${r}" 2>/dev/null || echo "ERR")
    [[ "$CODE" == "200" || "$CODE" == "302" ]] \
        && success "  http://$IP${r} → $CODE" \
        || warn "  http://$IP${r} → $CODE ← cek log"
done

echo ""
echo "Log: tail -f /var/log/apache2/zipay_error.log"
echo "PHP: tail -f /var/log/apache2/zipay_error.log | grep PHP"
