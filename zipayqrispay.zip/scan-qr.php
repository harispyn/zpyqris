<?php
// ============================================================
//  scan-qr.php – Scan QR via Kamera + Manual Input
//  Library: jsQR (UMD global, tidak butuh module/worker)
//  Fitur: auto-start jika izin kamera sudah pernah diberikan
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';

require_login();

$page_title = 'Scan QR';
$show_back  = true;
require __DIR__ . '/includes/layout_header.php';
?>

<style>
/* ── Page ─────────────────────────────────────────────────── */
.scan-page { padding: 16px 0 90px; }

/* ── Camera Card ─────────────────────────────────────────── */
.cam-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 4px 24px rgba(0,0,0,.10);
    overflow: hidden;
    margin-bottom: 16px;
}

/* ── Camera Viewport ─────────────────────────────────────── */
.cam-viewport {
    position: relative;
    width: 100%;
    background: #0a0a0a;
    aspect-ratio: 1 / 1;
    overflow: hidden;
    border-radius: 0;
}
.cam-viewport video,
.cam-viewport canvas#qr-canvas {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}
canvas#qr-canvas { display: none; }   /* hidden – hanya untuk decode */

/* ── Permission Placeholder ──────────────────────────────── */
#cam-placeholder {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 60%, #0f3460 100%);
    color: #fff;
    gap: 12px;
    padding: 24px;
    text-align: center;
}
#cam-placeholder .perm-icon {
    width: 72px; height: 72px;
    background: rgba(83,61,234,.25);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    animation: pulse 2s infinite;
}
#cam-placeholder .perm-icon svg { width: 36px; height: 36px; }
#cam-placeholder h4 { font-size: 16px; font-weight: 700; margin: 0; }
#cam-placeholder p  { font-size: 13px; color: rgba(255,255,255,.7); margin: 0; line-height: 1.4; }
.btn-allow-cam {
    background: #533dea;
    color: #fff;
    border: none;
    border-radius: 50px;
    padding: 12px 32px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 4px;
    transition: background .2s, transform .1s;
    box-shadow: 0 4px 16px rgba(83,61,234,.4);
}
.btn-allow-cam:active { transform: scale(.97); }
.btn-allow-cam:hover  { background: #4530c5; }

/* ── Scan Overlay (frame + laser) ────────────────────────── */
#scan-overlay {
    position: absolute;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    pointer-events: none;
}
#scan-overlay.visible { display: flex; }
.scan-frame {
    position: relative;
    width: 62%;
    aspect-ratio: 1 / 1;
}
.scan-frame::before, .scan-frame::after,
.scan-frame .c3, .scan-frame .c4 {
    content: ''; position: absolute;
    width: 22px; height: 22px;
    border-color: #fff; border-style: solid; border-width: 0;
}
.scan-frame::before { top:0;    left:0;  border-top-width:3px; border-left-width:3px;  border-radius:4px 0 0 0; }
.scan-frame::after  { top:0;    right:0; border-top-width:3px; border-right-width:3px; border-radius:0 4px 0 0; }
.scan-frame .c3     { bottom:0; left:0;  border-bottom-width:3px; border-left-width:3px;  border-radius:0 0 0 4px; }
.scan-frame .c4     { bottom:0; right:0; border-bottom-width:3px; border-right-width:3px; border-radius:0 0 4px 0; }
.scan-laser {
    position: absolute;
    inset-inline: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #4fc3f7 40%, #4fc3f7 60%, transparent);
    animation: laserMove 2s ease-in-out infinite;
    box-shadow: 0 0 6px #4fc3f7;
}
@keyframes laserMove {
    0%   { top: 4%;  opacity: 0; }
    10%  { opacity: 1; }
    90%  { opacity: 1; }
    100% { top: 94%; opacity: 0; }
}

/* ── QR Detected flash ───────────────────────────────────── */
.flash-detected {
    position: absolute;
    inset: 0;
    background: rgba(255,255,255,.35);
    animation: flashFade .3s ease-out forwards;
    pointer-events: none;
}
@keyframes flashFade {
    from { opacity: 1; }
    to   { opacity: 0; }
}

/* ── Status bar ──────────────────────────────────────────── */
.cam-status {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    padding: 8px 12px;
    font-size: 12px;
    font-weight: 600;
    text-align: center;
    letter-spacing: .3px;
}
.cam-status.idle      { background: rgba(0,0,0,.55); color: #ccc; }
.cam-status.scanning  { background: rgba(83,61,234,.75); color: #fff; }
.cam-status.success   { background: rgba(68,180,97,.85); color: #fff; }
.cam-status.error     { background: rgba(234,52,52,.85); color: #fff; }
.cam-status.loading   { background: rgba(0,0,0,.65); color: #aaa; }

/* ── Controls ────────────────────────────────────────────── */
.cam-controls {
    display: flex;
    gap: 10px;
    padding: 14px 16px;
    background: #fff;
}
.cam-controls button {
    flex: 1;
    padding: 11px 8px;
    border-radius: 12px;
    border: none;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: opacity .2s, transform .1s;
}
.cam-controls button:active { transform: scale(.97); }
.btn-start  { background: #533dea; color: #fff; }
.btn-stop   { background: #ea3434; color: #fff; }
.btn-flip   { background: #f5f5f5; color: #333; flex: 0 0 52px; }
#btn-start  { display: flex; }
#btn-stop   { display: none; }
#btn-flip   { display: none; }

/* ── Error panel ─────────────────────────────────────────── */
#cam-error-panel {
    display: none;
    padding: 14px 16px;
    background: #fdecea;
    border-top: 1px solid #f5c6cb;
}
#cam-error-panel p {
    margin: 0 0 10px;
    font-size: 13px;
    color: #b00020;
    line-height: 1.5;
}
#cam-error-panel .btn-retry {
    background: #533dea; color: #fff;
    border: none; border-radius: 10px;
    padding: 9px 20px; font-size: 13px; font-weight: 600;
    cursor: pointer;
}

/* ── Result card ─────────────────────────────────────────── */
#scan-result {
    display: none;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 4px 16px rgba(0,0,0,.08);
    overflow: hidden;
    margin-bottom: 16px;
    animation: slideUp .25s ease;
}
@keyframes slideUp {
    from { opacity:0; transform: translateY(12px); }
    to   { opacity:1; transform: translateY(0); }
}

/* ── Manual Input Card ───────────────────────────────────── */
.manual-card {
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 4px 24px rgba(0,0,0,.08);
    padding: 18px 16px;
    margin-bottom: 16px;
}
.manual-card h6 { font-size: 14px; font-weight: 700; margin: 0 0 12px; color: #1e1e1e; }
.manual-card .input-wrap { position: relative; }
.manual-card input {
    width: 100%;
    padding: 12px 14px;
    border: 1.5px solid #ddd;
    border-radius: 12px;
    font-size: 14px;
    outline: none;
    transition: border-color .2s;
    box-sizing: border-box;
}
.manual-card input:focus { border-color: #533dea; }
.manual-card button {
    width: 100%;
    margin-top: 10px;
    padding: 13px;
    background: #533dea;
    color: #fff;
    border: none;
    border-radius: 12px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
}

@keyframes pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(83,61,234,.4); }
    50%       { box-shadow: 0 0 0 12px rgba(83,61,234,0); }
}

/* ── Processing spinner ──────────────────────────────────── */
.spin-ring {
    width: 22px; height: 22px;
    border: 3px solid rgba(255,255,255,.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin .7s linear infinite;
    display: inline-block;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>

<!-- ── Page body ─────────────────────────────────────────── -->
<div class="tf-container">
  <div class="scan-page">

    <!-- Hidden CSRF -->
    <input type="hidden" id="csrf-token" value="<?= htmlspecialchars(csrf_token()) ?>">

    <!-- ── Camera Card ───────────────────────────────────── -->
    <div class="cam-card">

      <!-- Viewport -->
      <div class="cam-viewport" id="cam-viewport">

        <!-- Video stream -->
        <video id="qr-video" autoplay playsinline muted></video>

        <!-- Hidden canvas for jsQR decode -->
        <canvas id="qr-canvas"></canvas>

        <!-- Permission placeholder (shown first) -->
        <div id="cam-placeholder">
          <div class="perm-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1.8">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
              <circle cx="12" cy="13" r="4"/>
            </svg>
          </div>
          <h4>Izin Kamera Diperlukan</h4>
          <p>Kamera digunakan untuk membaca QR Code pembayaran. Tap tombol di bawah untuk mengizinkan.</p>
          <button class="btn-allow-cam" id="btn-allow">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
              <circle cx="12" cy="13" r="4"/>
            </svg>
            Izinkan Kamera
          </button>
        </div>

        <!-- Scan overlay (frame + laser) -->
        <div id="scan-overlay">
          <div class="scan-frame">
            <div class="c3"></div><div class="c4"></div>
            <div class="scan-laser"></div>
          </div>
        </div>

        <!-- Status bar -->
        <div class="cam-status idle" id="cam-status">Tekan Mulai untuk membuka kamera</div>
      </div>

      <!-- Controls -->
      <div class="cam-controls">
        <button class="btn-start" id="btn-start" onclick="startCamera()">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8" fill="currentColor" stroke="none"/>
          </svg>
          Mulai Scan
        </button>
        <button class="btn-stop" id="btn-stop" onclick="stopCamera()">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor">
            <rect x="6" y="6" width="12" height="12" rx="2"/>
          </svg>
          Stop
        </button>
        <button class="btn-flip" id="btn-flip" onclick="flipCamera()" title="Balik kamera">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M1 4v6h6"/><path d="M23 20v-6h-6"/>
            <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4-4.64 4.36A9 9 0 0 1 3.51 15"/>
          </svg>
        </button>
      </div>

      <!-- Error panel -->
      <div id="cam-error-panel">
        <p id="cam-error-msg">Kamera tidak dapat diakses.</p>
        <button class="btn-retry" onclick="retryCamera()">🔄 Coba Lagi</button>
      </div>

    </div><!-- /cam-card -->

    <!-- ── Scan Result ──────────────────────────────────── -->
    <div id="scan-result"></div>

    <!-- ── Manual Input ─────────────────────────────────── -->
    <div class="manual-card">
      <h6>✏️ Input Manual QR Code</h6>
      <div class="input-wrap">
        <input type="text" id="manual-input" placeholder="Tempel atau ketik kode QR di sini…"
               inputmode="text" autocomplete="off">
      </div>
      <button onclick="submitQR(document.getElementById('manual-input').value)">Proses QR Code</button>
    </div>

  </div><!-- /scan-page -->
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>

<!-- ── jsQR library (UMD global – bekerja tanpa module) ── -->
<script src="/javascript/jsqr.js"></script>

<script>
(function () {
    'use strict';

    /* ── State ─────────────────────────────────────────── */
    var stream       = null;
    var scanning     = false;
    var rafId        = null;
    var processing   = false;
    var facingMode   = 'environment';
    var csrfToken    = document.getElementById('csrf-token').value;

    /* ── DOM refs ───────────────────────────────────────── */
    var video       = document.getElementById('qr-video');
    var canvas      = document.getElementById('qr-canvas');
    var ctx         = canvas.getContext('2d', { willReadFrequently: true });
    var placeholder = document.getElementById('cam-placeholder');
    var overlay     = document.getElementById('scan-overlay');
    var statusEl    = document.getElementById('cam-status');
    var resultEl    = document.getElementById('scan-result');
    var errPanel    = document.getElementById('cam-error-panel');
    var errMsg      = document.getElementById('cam-error-msg');
    var btnStart    = document.getElementById('btn-start');
    var btnStop     = document.getElementById('btn-stop');
    var btnFlip     = document.getElementById('btn-flip');

    /* ── Verify jsQR loaded ─────────────────────────────── */
    if (typeof jsQR === 'undefined') {
        setStatus('❌ Library tidak termuat – refresh halaman', 'error');
        showError('jsQR library gagal dimuat. Pastikan file /javascript/jsqr.js ada di server dan refresh halaman.');
        return;
    }

    /* ── Helpers ────────────────────────────────────────── */
    function setStatus(msg, cls) {
        statusEl.textContent = msg;
        statusEl.className   = 'cam-status ' + (cls || 'idle');
    }

    function showError(msg) {
        errMsg.textContent        = msg;
        errPanel.style.display    = 'block';
        overlay.classList.remove('visible');
    }

    function hideError() {
        errPanel.style.display = 'none';
    }

    function showResult(html) {
        resultEl.innerHTML     = html;
        resultEl.style.display = 'block';
        resultEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    function hideResult() {
        resultEl.style.display = 'none';
        resultEl.innerHTML     = '';
    }

    function flashScreen() {
        var fl = document.createElement('div');
        fl.className = 'flash-detected';
        document.getElementById('cam-viewport').appendChild(fl);
        setTimeout(function () { fl.remove(); }, 350);
    }

    /* ── Camera start ───────────────────────────────────── */
    function startCamera() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            showError('Browser Anda tidak mendukung akses kamera. Gunakan Chrome/Firefox terbaru.');
            return;
        }
        hideError();
        hideResult();
        setStatus('⏳ Membuka kamera…', 'loading');
        btnStart.style.display = 'none';

        var constraints = {
            video: {
                facingMode: { ideal: facingMode },
                width:  { ideal: 1280 },
                height: { ideal: 720 }
            },
            audio: false
        };

        navigator.mediaDevices.getUserMedia(constraints)
            .then(function (s) {
                stream   = s;
                video.srcObject = s;

                video.addEventListener('loadedmetadata', function () {
                    video.play().then(function () {
                        placeholder.style.display = 'none';
                        overlay.classList.add('visible');
                        btnStart.style.display = 'none';
                        btnStop.style.display  = 'flex';
                        btnFlip.style.display  = 'flex';
                        scanning = true;
                        setStatus('🔍 Arahkan ke QR Code…', 'scanning');
                        requestAnimationFrame(tick);
                    }).catch(function (e) { handleCamError(e); });
                }, { once: true });
            })
            .catch(function (err) { handleCamError(err); });
    }
    window.startCamera = startCamera;

    /* ── Camera stop ────────────────────────────────────── */
    function stopCamera() {
        scanning = false;
        if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
        if (stream) {
            stream.getTracks().forEach(function (t) { t.stop(); });
            stream = null;
        }
        video.srcObject = null;
        overlay.classList.remove('visible');
        placeholder.style.display = 'flex';
        btnStop.style.display  = 'none';
        btnFlip.style.display  = 'none';
        btnStart.style.display = 'flex';
        setStatus('Kamera dihentikan', 'idle');
    }
    window.stopCamera = stopCamera;

    /* ── Flip camera ────────────────────────────────────── */
    function flipCamera() {
        facingMode = (facingMode === 'environment') ? 'user' : 'environment';
        stopCamera();
        setTimeout(startCamera, 200);
    }
    window.flipCamera = flipCamera;

    /* ── Retry after error ──────────────────────────────── */
    window.retryCamera = function () {
        hideError();
        btnStart.style.display = 'flex';
        startCamera();
    };

    /* ── Error handler ──────────────────────────────────── */
    function handleCamError(err) {
        scanning = false;
        if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
        btnStart.style.display = 'flex';
        btnStop.style.display  = 'none';
        btnFlip.style.display  = 'none';
        overlay.classList.remove('visible');
        setStatus('❌ Kamera gagal', 'error');

        var msg = (err && err.message) ? err.message : String(err);
        var name = (err && err.name)    ? err.name    : '';

        if (/NotAllowedError|PermissionDenied|Permission denied/i.test(name + msg)) {
            showError(
                '🔒 Izin kamera ditolak.\n\n' +
                'Cara mengizinkan:\n' +
                '• Chrome: Klik ikon 🔒 di address bar → Izin kamera → Izinkan\n' +
                '• Firefox: Klik ikon kamera di address bar → Izinkan\n' +
                '• Safari: Pengaturan → Safari → Kamera → Izinkan\n\n' +
                'Setelah mengizinkan, tekan "Coba Lagi".'
            );
        } else if (/NotFoundError|DevicesNotFound|no.*camera/i.test(name + msg)) {
            showError('📷 Tidak ada kamera ditemukan pada perangkat ini. Gunakan input manual di bawah.');
        } else if (/NotReadableError|TrackStartError|hardware/i.test(name + msg)) {
            showError('🔧 Kamera sedang digunakan aplikasi lain. Tutup aplikasi lain lalu coba lagi.');
        } else if (/OverconstrainedError/i.test(name + msg)) {
            // Fallback tanpa constraint ideal
            facingMode = 'environment';
            navigator.mediaDevices.getUserMedia({ video: true, audio: false })
                .then(function (s) {
                    stream = s;
                    video.srcObject = s;
                    video.addEventListener('loadedmetadata', function () {
                        video.play();
                        placeholder.style.display = 'none';
                        overlay.classList.add('visible');
                        btnStart.style.display = 'none';
                        btnStop.style.display  = 'flex';
                        btnFlip.style.display  = 'flex';
                        scanning = true;
                        setStatus('🔍 Arahkan ke QR Code…', 'scanning');
                        requestAnimationFrame(tick);
                    }, { once: true });
                })
                .catch(function (e2) { handleCamError(e2); });
            return;
        } else {
            showError('⚠️ Kamera tidak dapat diakses: ' + msg + '\n\nPastikan halaman diakses via HTTPS.');
        }
    }

    /* ── Decode loop (requestAnimationFrame) ────────────── */
    function tick() {
        if (!scanning) return;

        if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width  = video.videoWidth;
            canvas.height = video.videoHeight;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

            var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            var code = jsQR(imageData.data, imageData.width, imageData.height, {
                inversionAttempts: 'dontInvert'
            });

            if (code && code.data && !processing) {
                processing = true;
                scanning   = false;
                flashScreen();
                setStatus('✅ QR Terdeteksi!', 'success');
                overlay.classList.remove('visible');
                submitQR(code.data);
                return;
            }
        }

        rafId = requestAnimationFrame(tick);
    }

    /* ── Submit QR to server ────────────────────────────── */
    window.submitQR = function (qrData) {
        if (!qrData || !qrData.trim()) {
            alert('QR Code kosong atau tidak valid.');
            return;
        }

        setStatus('⏳ Memproses QR…', 'loading');
        hideResult();

        // Show loading
        showResult(
            '<div style="padding:24px;text-align:center;">' +
            '<div class="spin-ring" style="border-color:rgba(83,61,234,.25);border-top-color:#533dea;margin:0 auto 12px;width:32px;height:32px;"></div>' +
            '<p style="margin:0;color:#717171;font-size:14px;">Memproses pembayaran…</p>' +
            '</div>'
        );

        fetch('/process-qr', {
            method : 'POST',
            headers: {
                'Content-Type' : 'application/json',
                'X-CSRF-Token' : csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ qr_data: qrData.trim() })
        })
        .then(function (r) { return r.json(); })
        .then(function (data) {
            processing = false;
            if (data.success) {
                setStatus('✅ Pembayaran Berhasil!', 'success');
                showResult(
                    '<div style="padding:20px 16px;">' +
                    '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">' +
                    '<div style="width:40px;height:40px;background:#e8f5e9;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;">✅</div>' +
                    '<div><div style="font-weight:700;font-size:15px;color:#1b5e20;">Pembayaran Berhasil</div>' +
                    '<div style="font-size:12px;color:#717171;">QR Code diproses</div></div></div>' +
                    '<div style="background:#f8f8f8;border-radius:10px;padding:12px;font-size:13px;word-break:break-all;color:#333;margin-bottom:14px;">' +
                    '<strong>Data:</strong> ' + escHtml(qrData) + '</div>' +
                    (data.message ? '<p style="margin:0 0 14px;font-size:13px;color:#1b5e20;">' + escHtml(data.message) + '</p>' : '') +
                    '<div style="display:flex;gap:10px;">' +
                    '<button onclick="scanAgain()" style="flex:1;padding:11px;background:#533dea;color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;">Scan Lagi</button>' +
                    '<a href="/home" style="flex:1;padding:11px;background:#f5f5f5;color:#333;border-radius:10px;font-size:13px;font-weight:600;text-align:center;text-decoration:none;display:flex;align-items:center;justify-content:center;">Beranda</a>' +
                    '</div></div>'
                );
            } else {
                var errTxt = data.message || data.error || 'Terjadi kesalahan saat memproses QR.';
                setStatus('❌ Gagal', 'error');
                showResult(
                    '<div style="padding:20px 16px;">' +
                    '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">' +
                    '<div style="width:40px;height:40px;background:#fdecea;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;">❌</div>' +
                    '<div><div style="font-weight:700;font-size:15px;color:#b00020;">Pembayaran Gagal</div>' +
                    '<div style="font-size:12px;color:#717171;">Coba lagi atau hubungi support</div></div></div>' +
                    '<p style="margin:0 0 14px;font-size:13px;color:#b00020;">' + escHtml(errTxt) + '</p>' +
                    '<button onclick="scanAgain()" style="width:100%;padding:11px;background:#533dea;color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;">🔄 Scan Lagi</button>' +
                    '</div>'
                );
            }
        })
        .catch(function (err) {
            processing = false;
            setStatus('❌ Network error', 'error');
            showResult(
                '<div style="padding:20px 16px;text-align:center;">' +
                '<p style="color:#b00020;font-size:14px;">⚠️ Koneksi gagal: ' + escHtml(String(err)) + '</p>' +
                '<button onclick="scanAgain()" style="padding:11px 28px;background:#533dea;color:#fff;border:none;border-radius:10px;font-size:13px;font-weight:600;cursor:pointer;">Coba Lagi</button>' +
                '</div>'
            );
        });
    };

    /* ── Scan again helper ──────────────────────────────── */
    window.scanAgain = function () {
        hideResult();
        processing = false;
        scanning   = true;
        overlay.classList.add('visible');
        setStatus('🔍 Arahkan ke QR Code…', 'scanning');
        requestAnimationFrame(tick);
    };

    /* ── HTML escape ─────────────────────────────────────── */
    function escHtml(str) {
        return String(str)
            .replace(/&/g,'&amp;').replace(/</g,'&lt;')
            .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    /* ── Auto-start: cek permission saat halaman load ──── */
    document.addEventListener('DOMContentLoaded', function () {
        // Cek apakah permission kamera sudah pernah di-grant
        if (navigator.permissions) {
            navigator.permissions.query({ name: 'camera' }).then(function (result) {
                if (result.state === 'granted') {
                    // Langsung start tanpa perlu tombol
                    setStatus('⏳ Auto-membuka kamera…', 'loading');
                    btnStart.style.display = 'none';
                    setTimeout(startCamera, 300);
                } else if (result.state === 'prompt') {
                    // Belum pernah diminta – tampilkan placeholder + tombol
                    setStatus('Tap "Izinkan Kamera" untuk scan', 'idle');
                } else {
                    // denied
                    setStatus('Izin kamera ditolak', 'error');
                    showError(
                        '🔒 Izin kamera diblokir.\n' +
                        'Buka pengaturan browser → reset izin kamera untuk situs ini, lalu reload halaman.'
                    );
                }

                // Pantau perubahan permission
                result.onchange = function () {
                    if (result.state === 'granted' && !scanning) {
                        startCamera();
                    }
                };
            }).catch(function () {
                // Browser tidak support permissions API – biarkan user tap tombol
            });
        }

        // Tombol "Izinkan Kamera" di placeholder
        document.getElementById('btn-allow').addEventListener('click', startCamera);
    });

})();
</script>

<?php
// ── Navbar ────────────────────────────────────────────────────
?>
<div class="bottom-navigation-bar">
    <div class="tf-container">
        <div class="tf-tab-bar">
            <a href="/home"     class="item-tab"><i class="icon-home"></i><span>Home</span></a>
            <a href="/profile"  class="item-tab"><i class="icon-user1"></i><span>Profile</span></a>
            <a href="/qr-code"  class="item-tab"><i class="icon-qr-code"></i><span>QR</span></a>
            <a href="/scan-qr"  class="item-tab active"><i class="icon-scan"></i><span>Scan</span></a>
            <a href="/settings" class="item-tab"><i class="icon-settings"></i><span>Setting</span></a>
        </div>
    </div>
</div>
