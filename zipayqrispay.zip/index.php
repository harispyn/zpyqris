<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';

// Redirect ke home jika sudah login, atau ke login
if (is_logged_in()) {
    header('Location: /home');
} else {
    header('Location: /login');
}
exit;
