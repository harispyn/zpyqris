<?php
// ============================================================
//  verify-success.php – Halaman sukses verifikasi
// ============================================================
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session.php';

$page_title = 'Verifikasi Berhasil';
$show_back  = false;
require __DIR__ . '/includes/layout_header.php';
?>

<div class="verify-account-section">
    <div class="tf-container">
        <div class="image-box text-center mt-5">
            <img src="/images/user/register.jpg" alt="Berhasil" style="max-width:200px;">
        </div>
        <div class="tf-content mt-4 text-center">
            <h1 class="mb-2">Akun Terverifikasi!</h1>
            <p class="fw_4 mb-5">Akun Anda telah berhasil diverifikasi.<br>Silakan login untuk memulai transaksi.</p>
        </div>
        <a href="/login" class="tf-btn accent large">Mulai Login</a>
    </div>
</div>

<?php require __DIR__ . '/includes/layout_footer.php'; ?>
