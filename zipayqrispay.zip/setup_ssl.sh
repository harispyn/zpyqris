#!/usr/bin/env bash
# ================================================================
#  setup_ssl.sh – Pasang SSL/HTTPS untuk zipayku.xyz via Certbot
#  Jalankan: sudo bash setup_ssl.sh
#  Prasyarat: DNS A record sudah diarahkan ke IP server ini
# ================================================================

DOMAIN="zipayku.xyz"
APP_DIR="${APP_DIR:-/var/www/zipay}"
EMAIL="${SSL_EMAIL:-admin@zipayku.xyz}"   # Ganti dengan email Anda

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
success() { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; }

[[ $EUID -ne 0 ]] && { error "Jalankan sebagai root: sudo bash $0"; exit 1; }

SERVER_IP=$(hostname -I | awk '{print $1}')

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🔒 Setup SSL – ${DOMAIN}"
echo "  Server IP : ${SERVER_IP}"
echo "  Email     : ${EMAIL}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 1. Cek DNS ────────────────────────────────────────────────────
info "1. Cek DNS ${DOMAIN}..."
DOMAIN_IP=$(dig +short ${DOMAIN} 2>/dev/null | tail -1)
WWW_IP=$(dig +short www.${DOMAIN} 2>/dev/null | tail -1)

DNS_OK=1
if [[ "$DOMAIN_IP" != "$SERVER_IP" ]]; then
    error "DNS ${DOMAIN} → ${DOMAIN_IP} (seharusnya ${SERVER_IP})"
    DNS_OK=0
else
    success "DNS ${DOMAIN} → ${SERVER_IP} ✓"
fi

if [[ "$WWW_IP" != "$SERVER_IP" ]]; then
    warn "DNS www.${DOMAIN} → ${WWW_IP} (seharusnya ${SERVER_IP})"
    warn "www bisa dilewati, tapi sebaiknya juga di-set"
else
    success "DNS www.${DOMAIN} → ${SERVER_IP} ✓"
fi

if [[ $DNS_OK -eq 0 ]]; then
    error "DNS belum propagasi. Certbot akan GAGAL jika DNS tidak mengarah ke server ini."
    echo ""
    echo "  Langkah:"
    echo "  1. Login ke registrar domain (Namecheap, GoDaddy, dll)"
    echo "  2. Tambahkan A record:"
    echo "       ${DOMAIN}     →  ${SERVER_IP}"
    echo "       www.${DOMAIN} →  ${SERVER_IP}"
    echo "  3. Tunggu propagasi DNS (5-30 menit)"
    echo "  4. Jalankan lagi: sudo bash setup_ssl.sh"
    echo ""
    read -p "Lanjutkan meskipun DNS belum OK? (yes/no) [no]: " CONFIRM
    [[ "$CONFIRM" != "yes" ]] && exit 1
fi

# ── 2. Install Certbot ────────────────────────────────────────────
info "2. Install Certbot..."
apt-get update -q
apt-get install -y -q certbot python3-certbot-apache
if command -v certbot &>/dev/null; then
    success "Certbot: $(certbot --version 2>&1)"
else
    error "Certbot gagal install!"
    exit 1
fi

# ── 3. Pastikan Apache berjalan ───────────────────────────────────
info "3. Cek Apache..."
if ! systemctl is-active --quiet apache2; then
    info "Apache tidak berjalan, memulai..."
    systemctl start apache2
fi
success "Apache berjalan"

# ── 4. Pastikan port 80 accessible (cek firewall) ─────────────────
info "4. Cek firewall (ufw)..."
if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow 80/tcp 2>/dev/null
    ufw allow 443/tcp 2>/dev/null
    ufw allow 'Apache Full' 2>/dev/null
    success "UFW: port 80 & 443 dibuka"
else
    info "UFW tidak aktif atau tidak ditemukan"
fi

# Cek iptables juga
iptables -I INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || true
iptables -I INPUT -p tcp --dport 443 -j ACCEPT 2>/dev/null || true

# ── 5. Request SSL certificate ────────────────────────────────────
info "5. Request SSL certificate dari Let's Encrypt..."
echo ""
warn "Certbot akan otomatis:"
warn "  - Request certificate dari Let's Encrypt"
warn "  - Modifikasi Apache VirtualHost untuk HTTPS"
warn "  - Setup auto-renew"
echo ""

certbot --apache \
    -d ${DOMAIN} \
    -d www.${DOMAIN} \
    --email ${EMAIL} \
    --agree-tos \
    --no-eff-email \
    --redirect \
    --non-interactive 2>&1

CERTBOT_EXIT=$?

if [[ $CERTBOT_EXIT -eq 0 ]]; then
    success "SSL certificate berhasil dipasang! ✓"

    # ── 6. Update config.php ke HTTPS ────────────────────────────
    info "6. Update config.php ke HTTPS..."
    if [[ -f "${APP_DIR}/config.php" ]]; then
        sed -i "s|define('APP_URL'.*)|define('APP_URL',   'https://${DOMAIN}');|" "${APP_DIR}/config.php"
        success "config.php APP_URL → https://${DOMAIN}"
    fi

    # ── 7. Cek auto-renew ────────────────────────────────────────
    info "7. Setup auto-renew cron..."
    if ! crontab -l 2>/dev/null | grep -q "certbot renew"; then
        (crontab -l 2>/dev/null; echo "0 3 * * * certbot renew --quiet --post-hook 'systemctl reload apache2'") | crontab -
        success "Cron auto-renew dipasang (setiap hari jam 03:00)"
    else
        success "Cron auto-renew sudah ada"
    fi

    # ── 8. Test HTTPS ─────────────────────────────────────────────
    info "8. Test HTTPS..."
    sleep 2
    HTTPS_CODE=$(curl -sk -o /dev/null -w "%{http_code}" "https://${DOMAIN}" 2>/dev/null || echo "ERR")
    if [[ "$HTTPS_CODE" == "200" || "$HTTPS_CODE" == "302" ]]; then
        success "https://${DOMAIN} → $HTTPS_CODE ✓"
    else
        warn "https://${DOMAIN} → $HTTPS_CODE (mungkin perlu tunggu beberapa detik)"
    fi

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    success "  🎉 SSL BERHASIL DIPASANG!"
    echo ""
    echo "  🌐 Site URL   : https://${DOMAIN}"
    echo "  🔑 Cert path  : /etc/letsencrypt/live/${DOMAIN}/"
    echo "  🔄 Auto-renew : Setiap hari jam 03:00"
    echo ""
    echo "  Test renew  : certbot renew --dry-run"
    echo "  Cek cert    : certbot certificates"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

else
    error "Certbot GAGAL (exit code: $CERTBOT_EXIT)"
    echo ""
    echo "  Kemungkinan penyebab:"
    echo "  1. DNS belum propagasi (tunggu 5-30 menit)"
    echo "  2. Port 80 diblokir firewall"
    echo "  3. Domain tidak mengarah ke server ini"
    echo ""
    echo "  Debug:"
    echo "    dig ${DOMAIN}          # Cek DNS"
    echo "    curl http://${DOMAIN}  # Cek akses HTTP"
    echo "    certbot --apache -d ${DOMAIN} --staging  # Test mode"
    echo ""
    warn "Self-signed cert sebagai fallback..."

    # Fallback: self-signed certificate
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/ssl/private/zipay_selfsigned.key \
        -out    /etc/ssl/certs/zipay_selfsigned.crt \
        -subj   "/C=ID/ST=Jakarta/L=Jakarta/O=Zipay/CN=${DOMAIN}" 2>/dev/null

    if [[ $? -eq 0 ]]; then
        success "Self-signed cert dibuat (browser akan kasih warning)"
        # Update VirtualHost untuk self-signed
        cat >> /etc/apache2/sites-available/zipay.conf << SSLEOF

<VirtualHost *:443>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    DocumentRoot ${APP_DIR}
    SSLEngine on
    SSLCertificateFile    /etc/ssl/certs/zipay_selfsigned.crt
    SSLCertificateKeyFile /etc/ssl/private/zipay_selfsigned.key
    <Directory ${APP_DIR}>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    ErrorLog  /var/log/apache2/zipay_error.log
    CustomLog /var/log/apache2/zipay_access.log combined
</VirtualHost>
SSLEOF
        systemctl restart apache2
        warn "Self-signed SSL aktif (https://${DOMAIN} – browser warning normal)"
        warn "Setelah DNS OK, jalankan lagi: sudo bash setup_ssl.sh"
    fi
fi
